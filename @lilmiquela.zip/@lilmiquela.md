```python
pip install emoji
```

    Requirement already satisfied: emoji in /opt/conda/envs/python3/lib/python3.7/site-packages (0.6.0)
    Note: you may need to restart the kernel to use updated packages.



```python
pip install WordCloud
```

    Requirement already satisfied: WordCloud in /opt/conda/envs/python3/lib/python3.7/site-packages (1.8.1)
    Requirement already satisfied: pillow in /opt/conda/envs/python3/lib/python3.7/site-packages (from WordCloud) (7.1.2)
    Requirement already satisfied: matplotlib in /opt/conda/envs/python3/lib/python3.7/site-packages (from WordCloud) (3.1.2)
    Requirement already satisfied: numpy>=1.6.1 in /opt/conda/envs/python3/lib/python3.7/site-packages (from WordCloud) (1.18.0)
    Requirement already satisfied: pyparsing!=2.0.4,!=2.1.2,!=2.1.6,>=2.0.1 in /opt/conda/envs/python3/lib/python3.7/site-packages (from matplotlib->WordCloud) (2.4.6)
    Requirement already satisfied: python-dateutil>=2.1 in /opt/conda/envs/python3/lib/python3.7/site-packages (from matplotlib->WordCloud) (2.8.1)
    Requirement already satisfied: cycler>=0.10 in /opt/conda/envs/python3/lib/python3.7/site-packages (from matplotlib->WordCloud) (0.10.0)
    Requirement already satisfied: kiwisolver>=1.0.1 in /opt/conda/envs/python3/lib/python3.7/site-packages (from matplotlib->WordCloud) (1.1.0)
    Requirement already satisfied: six>=1.5 in /opt/conda/envs/python3/lib/python3.7/site-packages (from python-dateutil>=2.1->matplotlib->WordCloud) (1.13.0)
    Requirement already satisfied: setuptools in /opt/conda/envs/python3/lib/python3.7/site-packages (from kiwisolver>=1.0.1->matplotlib->WordCloud) (44.0.0.post20200102)
    Note: you may need to restart the kernel to use updated packages.



```python
pip install nltk
```

    Requirement already satisfied: nltk in /opt/conda/envs/python3/lib/python3.7/site-packages (3.5)
    Requirement already satisfied: click in /opt/conda/envs/python3/lib/python3.7/site-packages (from nltk) (7.1.2)
    Requirement already satisfied: tqdm in /opt/conda/envs/python3/lib/python3.7/site-packages (from nltk) (4.45.0)
    Requirement already satisfied: regex in /opt/conda/envs/python3/lib/python3.7/site-packages (from nltk) (2020.11.13)
    Requirement already satisfied: joblib in /opt/conda/envs/python3/lib/python3.7/site-packages (from nltk) (0.13.2)
    Note: you may need to restart the kernel to use updated packages.



```python
pip install TextBlob
```

    Requirement already satisfied: TextBlob in /opt/conda/envs/python3/lib/python3.7/site-packages (0.15.3)
    Requirement already satisfied: nltk>=3.1 in /opt/conda/envs/python3/lib/python3.7/site-packages (from TextBlob) (3.5)
    Requirement already satisfied: click in /opt/conda/envs/python3/lib/python3.7/site-packages (from nltk>=3.1->TextBlob) (7.1.2)
    Requirement already satisfied: regex in /opt/conda/envs/python3/lib/python3.7/site-packages (from nltk>=3.1->TextBlob) (2020.11.13)
    Requirement already satisfied: joblib in /opt/conda/envs/python3/lib/python3.7/site-packages (from nltk>=3.1->TextBlob) (0.13.2)
    Requirement already satisfied: tqdm in /opt/conda/envs/python3/lib/python3.7/site-packages (from nltk>=3.1->TextBlob) (4.45.0)
    Note: you may need to restart the kernel to use updated packages.



```python
pip install altair
```

    Requirement already satisfied: altair in /opt/conda/envs/python3/lib/python3.7/site-packages (4.1.0)
    Requirement already satisfied: jsonschema in /opt/conda/envs/python3/lib/python3.7/site-packages (from altair) (3.2.0)
    Requirement already satisfied: numpy in /opt/conda/envs/python3/lib/python3.7/site-packages (from altair) (1.18.0)
    Requirement already satisfied: pandas>=0.18 in /opt/conda/envs/python3/lib/python3.7/site-packages (from altair) (0.25.3)
    Requirement already satisfied: jinja2 in /opt/conda/envs/python3/lib/python3.7/site-packages (from altair) (2.10.3)
    Requirement already satisfied: toolz in /opt/conda/envs/python3/lib/python3.7/site-packages (from altair) (0.10.0)
    Requirement already satisfied: entrypoints in /opt/conda/envs/python3/lib/python3.7/site-packages (from altair) (0.3)
    Requirement already satisfied: attrs>=17.4.0 in /opt/conda/envs/python3/lib/python3.7/site-packages (from jsonschema->altair) (19.3.0)
    Requirement already satisfied: six>=1.11.0 in /opt/conda/envs/python3/lib/python3.7/site-packages (from jsonschema->altair) (1.13.0)
    Requirement already satisfied: importlib-metadata; python_version < "3.8" in /opt/conda/envs/python3/lib/python3.7/site-packages (from jsonschema->altair) (1.3.0)
    Requirement already satisfied: setuptools in /opt/conda/envs/python3/lib/python3.7/site-packages (from jsonschema->altair) (44.0.0.post20200102)
    Requirement already satisfied: pyrsistent>=0.14.0 in /opt/conda/envs/python3/lib/python3.7/site-packages (from jsonschema->altair) (0.15.6)
    Requirement already satisfied: python-dateutil>=2.6.1 in /opt/conda/envs/python3/lib/python3.7/site-packages (from pandas>=0.18->altair) (2.8.1)
    Requirement already satisfied: pytz>=2017.2 in /opt/conda/envs/python3/lib/python3.7/site-packages (from pandas>=0.18->altair) (2019.3)
    Requirement already satisfied: MarkupSafe>=0.23 in /opt/conda/envs/python3/lib/python3.7/site-packages (from jinja2->altair) (1.1.1)
    Requirement already satisfied: zipp>=0.5 in /opt/conda/envs/python3/lib/python3.7/site-packages (from importlib-metadata; python_version < "3.8"->jsonschema->altair) (0.6.0)
    Requirement already satisfied: more-itertools in /opt/conda/envs/python3/lib/python3.7/site-packages (from zipp>=0.5->importlib-metadata; python_version < "3.8"->jsonschema->altair) (8.0.2)
    Note: you may need to restart the kernel to use updated packages.



```python
pip install stopwords
```

    Requirement already satisfied: stopwords in /opt/conda/envs/python3/lib/python3.7/site-packages (1.0.0)
    Note: you may need to restart the kernel to use updated packages.



```python
pip install igramscraper
```

    Requirement already satisfied: igramscraper in /opt/conda/envs/python3/lib/python3.7/site-packages (0.3.5)
    Requirement already satisfied: python-slugify==3.0.2 in /opt/conda/envs/python3/lib/python3.7/site-packages (from igramscraper) (3.0.2)
    Requirement already satisfied: requests>=2.21.0 in /opt/conda/envs/python3/lib/python3.7/site-packages (from igramscraper) (2.23.0)
    Requirement already satisfied: text-unidecode==1.2 in /opt/conda/envs/python3/lib/python3.7/site-packages (from python-slugify==3.0.2->igramscraper) (1.2)
    Requirement already satisfied: urllib3!=1.25.0,!=1.25.1,<1.26,>=1.21.1 in /opt/conda/envs/python3/lib/python3.7/site-packages (from requests>=2.21.0->igramscraper) (1.25.9)
    Requirement already satisfied: certifi>=2017.4.17 in /opt/conda/envs/python3/lib/python3.7/site-packages (from requests>=2.21.0->igramscraper) (2019.11.28)
    Requirement already satisfied: chardet<4,>=3.0.2 in /opt/conda/envs/python3/lib/python3.7/site-packages (from requests>=2.21.0->igramscraper) (3.0.4)
    Requirement already satisfied: idna<3,>=2.5 in /opt/conda/envs/python3/lib/python3.7/site-packages (from requests>=2.21.0->igramscraper) (2.9)
    Note: you may need to restart the kernel to use updated packages.



```python
import pandas as pd
import string
import altair as alt #importerer 'altair' som 'alt'
from textblob import TextBlob
import nltk
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.linear_model import LinearRegression 
from sklearn.metrics import r2_score
import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import mean_squared_error, r2_score
import emoji
import regex
from IPython.display import Image
from igramscraper.instagram import Instagram
from collections import Counter
from nltk.corpus import stopwords
from wordcloud import WordCloud
```

# Robotinfluencers på Instagram

Indledning her...

I dette projektet ønsker vi at undersøge, hvad der karakteriserer instagramrobotten @lilmiquelas brug af instagram. Vi opstiller altså et casestudie, der har til formål på baggrund af åbne datavidenskabelige principper at empirisk afdække et nyt fænomen. 


```python
Image(filename='Skærmbillede 2020-12-14 kl. 17.07.40.png')
```




![png](output_9_0.png)



### Hvem er @lilmiquela


```python
instagram = Instagram() #gør brug af biblioteket 'igramscraper.instagram'

account = instagram.get_account_by_id(3089598226) #instagramprofilens bruger-id

# printer relevant data fra @lilmiquelas instagramprofil
print('Account info:')
print('Id: ', account.identifier)
print('Username: ', account.username)
print('Full name: ', account.full_name)
print('Number of published posts: ', account.media_count)
print('Number of followers: ', account.followed_by_count)
print('Number of follows: ', account.follows_count)
print('Is private: ', account.is_private)
print('Is verified: ', account.is_verified)
print('Biography: ', account.biography)
```

    Account info:
    Id:  3089598226
    Username:  lilmiquela
    Full name:  Miquela
    Number of published posts:  948
    Number of followers:  2919809
    Number of follows:  1886
    Is private:  False
    Is verified:  True
    Biography:  #BlackLivesMatter
    Change-seeking robot with the drip💧💖
    ⬇️ Get Real, Miquela ✨NEW EPISODE✨


Influenceren @lilmiquela er en robot/virtuel instagrammer. Hun er programmeret som en 19-årig pige bosiddende i LA og har med sine 2,9 mio følgere skabt en masse popularitet og kontroverser på det sociale medie instagram, hvor hun bl.a. reklamerer for high-end brands og promoverer sin støtte til blandt andet #BlackLivesMatter og andre interessebevægelser. Hun deler dagligt indhold relateret til sin hverdag, herunder kæresteproblemer, ‘Outfit of the day’ og ‘storytimes’ - problematikken bunder dog i, at hun i virkeligheden ikke eksisterer, da alt hendes indhold er baseret på et fiktivt narrativ omkring hendes robotidentitet kreereret af virksomheden Brud.

Til generering af relevant data omkring @lilmiquelas instagramopslag, gør vi metoden 'web scraping'

# Web scraping og generering af CSV-fil


```python

Image(filename='Skærmbillede 2020-12-07 kl. 11.24.38.png')
```




![png](output_14_0.png)



#### Skal ændres til det rigtige billede og linket skal sættes ind
_________


## Det genererede datasæt


```python
df=pd.read_csv('example_username-copy.csv')
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>link</th>
      <th>type</th>
      <th>likes/views</th>
      <th>age</th>
      <th>comment</th>
      <th>hashtags</th>
      <th>mentions</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>https://www.instagram.com/p/CHTOZ8-nnfG/</td>
      <td>photo</td>
      <td>43,282</td>
      <td>1h</td>
      <td>This is the first step of MANY. KEEP THAT SAME...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>https://www.instagram.com/p/CHQ6AWXnW5J/</td>
      <td>photo</td>
      <td>34,263</td>
      <td>17h</td>
      <td>Wearing all Praying cause that's what all I be...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>https://www.instagram.com/p/CHOsztcHHXF/</td>
      <td>photo</td>
      <td>44,715</td>
      <td>1d</td>
      <td>Fav distraction: Looking at apartments I can't...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>https://www.instagram.com/p/CHLts9MnWam/</td>
      <td>photo</td>
      <td>41,334</td>
      <td>1d</td>
      <td>I know patience is a virtue, but DAMN!! Are we...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>https://www.instagram.com/p/CHJocBknqe-/</td>
      <td>photo</td>
      <td>53,704</td>
      <td>1d</td>
      <td>Anxiety meter already broke 🤖 Recharging with ...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>245</th>
      <td>245</td>
      <td>https://www.instagram.com/p/B9hpoJ_noAc/</td>
      <td>photo</td>
      <td>72,411</td>
      <td>26w</td>
      <td>Went through a breakup, wrote a song about it....</td>
      <td>#SpeakUp</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>246</th>
      <td>246</td>
      <td>https://www.instagram.com/p/B9estyun6U1/</td>
      <td>video</td>
      <td>1,319,915</td>
      <td>15w</td>
      <td>Y’all know how I am...I couldn’t help myself 🙃...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>247</th>
      <td>247</td>
      <td>https://www.instagram.com/p/B9cNh70HQLH/</td>
      <td>video</td>
      <td>2,826,650</td>
      <td>4w</td>
      <td>Big things coming soon!</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>248</th>
      <td>248</td>
      <td>https://www.instagram.com/p/B9ZzyfGna6a/</td>
      <td>photo</td>
      <td>41,180</td>
      <td>28w</td>
      <td>New tunes coming soon. Zoom in on my @samsungm...</td>
      <td>['#TeamGalaxy', '#ad']</td>
      <td>@samsungmobile</td>
    </tr>
    <tr>
      <th>249</th>
      <td>249</td>
      <td>https://www.instagram.com/p/B9XstBrHqrj/</td>
      <td>photo</td>
      <td>86,739</td>
      <td>7w</td>
      <td>⚠️ Long caption Alert ⚠️\nSo this is the inevi...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>250 rows × 8 columns</p>
</div>



# Datarensning


```python
#Oversigt over datasættes feautures
df.columns
```




    Index(['Unnamed: 0', 'link', 'type', 'likes/views', 'age', 'comment',
           'hashtags', 'mentions'],
          dtype='object')




```python
df=df.rename(columns={"Unnamed: 0": "post number", "comment": "caption"})
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>post number</th>
      <th>link</th>
      <th>type</th>
      <th>likes/views</th>
      <th>age</th>
      <th>caption</th>
      <th>hashtags</th>
      <th>mentions</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>https://www.instagram.com/p/CHTOZ8-nnfG/</td>
      <td>photo</td>
      <td>43,282</td>
      <td>1h</td>
      <td>This is the first step of MANY. KEEP THAT SAME...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>https://www.instagram.com/p/CHQ6AWXnW5J/</td>
      <td>photo</td>
      <td>34,263</td>
      <td>17h</td>
      <td>Wearing all Praying cause that's what all I be...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>https://www.instagram.com/p/CHOsztcHHXF/</td>
      <td>photo</td>
      <td>44,715</td>
      <td>1d</td>
      <td>Fav distraction: Looking at apartments I can't...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>https://www.instagram.com/p/CHLts9MnWam/</td>
      <td>photo</td>
      <td>41,334</td>
      <td>1d</td>
      <td>I know patience is a virtue, but DAMN!! Are we...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>https://www.instagram.com/p/CHJocBknqe-/</td>
      <td>photo</td>
      <td>53,704</td>
      <td>1d</td>
      <td>Anxiety meter already broke 🤖 Recharging with ...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.columns
```




    Index(['post number', 'link', 'type', 'likes/views', 'age', 'caption',
           'hashtags', 'mentions'],
          dtype='object')




```python
to_drop=['age'] # Her har vi fjernet en masse data, som ikke indeholdte brugbar information
df.drop(to_drop, inplace=True, axis=1)
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>post number</th>
      <th>link</th>
      <th>type</th>
      <th>likes/views</th>
      <th>caption</th>
      <th>hashtags</th>
      <th>mentions</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>https://www.instagram.com/p/CHTOZ8-nnfG/</td>
      <td>photo</td>
      <td>43,282</td>
      <td>This is the first step of MANY. KEEP THAT SAME...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>https://www.instagram.com/p/CHQ6AWXnW5J/</td>
      <td>photo</td>
      <td>34,263</td>
      <td>Wearing all Praying cause that's what all I be...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>https://www.instagram.com/p/CHOsztcHHXF/</td>
      <td>photo</td>
      <td>44,715</td>
      <td>Fav distraction: Looking at apartments I can't...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>https://www.instagram.com/p/CHLts9MnWam/</td>
      <td>photo</td>
      <td>41,334</td>
      <td>I know patience is a virtue, but DAMN!! Are we...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>https://www.instagram.com/p/CHJocBknqe-/</td>
      <td>photo</td>
      <td>53,704</td>
      <td>Anxiety meter already broke 🤖 Recharging with ...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Erstatter komma med ingen ting og konverterer likes/views til integer
df['likes/views'] = df['likes/views'].str.replace(",","").astype(int)
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>post number</th>
      <th>link</th>
      <th>type</th>
      <th>likes/views</th>
      <th>caption</th>
      <th>hashtags</th>
      <th>mentions</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>https://www.instagram.com/p/CHTOZ8-nnfG/</td>
      <td>photo</td>
      <td>43282</td>
      <td>This is the first step of MANY. KEEP THAT SAME...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>https://www.instagram.com/p/CHQ6AWXnW5J/</td>
      <td>photo</td>
      <td>34263</td>
      <td>Wearing all Praying cause that's what all I be...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>https://www.instagram.com/p/CHOsztcHHXF/</td>
      <td>photo</td>
      <td>44715</td>
      <td>Fav distraction: Looking at apartments I can't...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>https://www.instagram.com/p/CHLts9MnWam/</td>
      <td>photo</td>
      <td>41334</td>
      <td>I know patience is a virtue, but DAMN!! Are we...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>https://www.instagram.com/p/CHJocBknqe-/</td>
      <td>photo</td>
      <td>53704</td>
      <td>Anxiety meter already broke 🤖 Recharging with ...</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.dtypes
```




    post number     int64
    link           object
    type           object
    likes/views     int64
    caption        object
    hashtags       object
    mentions       object
    dtype: object




```python
#antal tegn
df["caption length"]= df["caption"].str.len()
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>post number</th>
      <th>link</th>
      <th>type</th>
      <th>likes/views</th>
      <th>caption</th>
      <th>hashtags</th>
      <th>mentions</th>
      <th>caption length</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>https://www.instagram.com/p/CHTOZ8-nnfG/</td>
      <td>photo</td>
      <td>43282</td>
      <td>This is the first step of MANY. KEEP THAT SAME...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>82</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>https://www.instagram.com/p/CHQ6AWXnW5J/</td>
      <td>photo</td>
      <td>34263</td>
      <td>Wearing all Praying cause that's what all I be...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>55</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>https://www.instagram.com/p/CHOsztcHHXF/</td>
      <td>photo</td>
      <td>44715</td>
      <td>Fav distraction: Looking at apartments I can't...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>73</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>https://www.instagram.com/p/CHLts9MnWam/</td>
      <td>photo</td>
      <td>41334</td>
      <td>I know patience is a virtue, but DAMN!! Are we...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>102</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>https://www.instagram.com/p/CHJocBknqe-/</td>
      <td>photo</td>
      <td>53704</td>
      <td>Anxiety meter already broke 🤖 Recharging with ...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>90</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>245</th>
      <td>245</td>
      <td>https://www.instagram.com/p/B9hpoJ_noAc/</td>
      <td>photo</td>
      <td>72411</td>
      <td>Went through a breakup, wrote a song about it....</td>
      <td>#SpeakUp</td>
      <td>NaN</td>
      <td>119</td>
    </tr>
    <tr>
      <th>246</th>
      <td>246</td>
      <td>https://www.instagram.com/p/B9estyun6U1/</td>
      <td>video</td>
      <td>1319915</td>
      <td>Y’all know how I am...I couldn’t help myself 🙃...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>59</td>
    </tr>
    <tr>
      <th>247</th>
      <td>247</td>
      <td>https://www.instagram.com/p/B9cNh70HQLH/</td>
      <td>video</td>
      <td>2826650</td>
      <td>Big things coming soon!</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>23</td>
    </tr>
    <tr>
      <th>248</th>
      <td>248</td>
      <td>https://www.instagram.com/p/B9ZzyfGna6a/</td>
      <td>photo</td>
      <td>41180</td>
      <td>New tunes coming soon. Zoom in on my @samsungm...</td>
      <td>['#TeamGalaxy', '#ad']</td>
      <td>@samsungmobile</td>
      <td>243</td>
    </tr>
    <tr>
      <th>249</th>
      <td>249</td>
      <td>https://www.instagram.com/p/B9XstBrHqrj/</td>
      <td>photo</td>
      <td>86739</td>
      <td>⚠️ Long caption Alert ⚠️\nSo this is the inevi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1487</td>
    </tr>
  </tbody>
</table>
<p>250 rows × 8 columns</p>
</div>




```python
def split_count(caption):
    return len([i for i in caption if i in emoji.UNICODE_EMOJI])
df["emoji count"] = df["caption"].apply(split_count)
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>post number</th>
      <th>link</th>
      <th>type</th>
      <th>likes/views</th>
      <th>caption</th>
      <th>hashtags</th>
      <th>mentions</th>
      <th>caption length</th>
      <th>emoji count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>https://www.instagram.com/p/CHTOZ8-nnfG/</td>
      <td>photo</td>
      <td>43282</td>
      <td>This is the first step of MANY. KEEP THAT SAME...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>82</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>https://www.instagram.com/p/CHQ6AWXnW5J/</td>
      <td>photo</td>
      <td>34263</td>
      <td>Wearing all Praying cause that's what all I be...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>55</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>https://www.instagram.com/p/CHOsztcHHXF/</td>
      <td>photo</td>
      <td>44715</td>
      <td>Fav distraction: Looking at apartments I can't...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>73</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>https://www.instagram.com/p/CHLts9MnWam/</td>
      <td>photo</td>
      <td>41334</td>
      <td>I know patience is a virtue, but DAMN!! Are we...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>102</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>https://www.instagram.com/p/CHJocBknqe-/</td>
      <td>photo</td>
      <td>53704</td>
      <td>Anxiety meter already broke 🤖 Recharging with ...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>90</td>
      <td>3</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>245</th>
      <td>245</td>
      <td>https://www.instagram.com/p/B9hpoJ_noAc/</td>
      <td>photo</td>
      <td>72411</td>
      <td>Went through a breakup, wrote a song about it....</td>
      <td>#SpeakUp</td>
      <td>NaN</td>
      <td>119</td>
      <td>0</td>
    </tr>
    <tr>
      <th>246</th>
      <td>246</td>
      <td>https://www.instagram.com/p/B9estyun6U1/</td>
      <td>video</td>
      <td>1319915</td>
      <td>Y’all know how I am...I couldn’t help myself 🙃...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>59</td>
      <td>1</td>
    </tr>
    <tr>
      <th>247</th>
      <td>247</td>
      <td>https://www.instagram.com/p/B9cNh70HQLH/</td>
      <td>video</td>
      <td>2826650</td>
      <td>Big things coming soon!</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>23</td>
      <td>0</td>
    </tr>
    <tr>
      <th>248</th>
      <td>248</td>
      <td>https://www.instagram.com/p/B9ZzyfGna6a/</td>
      <td>photo</td>
      <td>41180</td>
      <td>New tunes coming soon. Zoom in on my @samsungm...</td>
      <td>['#TeamGalaxy', '#ad']</td>
      <td>@samsungmobile</td>
      <td>243</td>
      <td>3</td>
    </tr>
    <tr>
      <th>249</th>
      <td>249</td>
      <td>https://www.instagram.com/p/B9XstBrHqrj/</td>
      <td>photo</td>
      <td>86739</td>
      <td>⚠️ Long caption Alert ⚠️\nSo this is the inevi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1487</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
<p>250 rows × 9 columns</p>
</div>




```python
# Ny kolonne med antal hastags for hvert post
df["hashtag count"]= df["hashtags"].str.count('#')
df.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>post number</th>
      <th>link</th>
      <th>type</th>
      <th>likes/views</th>
      <th>caption</th>
      <th>hashtags</th>
      <th>mentions</th>
      <th>caption length</th>
      <th>emoji count</th>
      <th>hashtag count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>https://www.instagram.com/p/CHTOZ8-nnfG/</td>
      <td>photo</td>
      <td>43282</td>
      <td>This is the first step of MANY. KEEP THAT SAME...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>82</td>
      <td>0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>https://www.instagram.com/p/CHQ6AWXnW5J/</td>
      <td>photo</td>
      <td>34263</td>
      <td>Wearing all Praying cause that's what all I be...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>55</td>
      <td>1</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>https://www.instagram.com/p/CHOsztcHHXF/</td>
      <td>photo</td>
      <td>44715</td>
      <td>Fav distraction: Looking at apartments I can't...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>73</td>
      <td>0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>https://www.instagram.com/p/CHLts9MnWam/</td>
      <td>photo</td>
      <td>41334</td>
      <td>I know patience is a virtue, but DAMN!! Are we...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>102</td>
      <td>0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>https://www.instagram.com/p/CHJocBknqe-/</td>
      <td>photo</td>
      <td>53704</td>
      <td>Anxiety meter already broke 🤖 Recharging with ...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>90</td>
      <td>3</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Ny kolonne med antal hastags for hvert post
df["mentions count"]= df["mentions"].str.count('@')
df.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>post number</th>
      <th>link</th>
      <th>type</th>
      <th>likes/views</th>
      <th>caption</th>
      <th>hashtags</th>
      <th>mentions</th>
      <th>caption length</th>
      <th>emoji count</th>
      <th>hashtag count</th>
      <th>mentions count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>https://www.instagram.com/p/CHTOZ8-nnfG/</td>
      <td>photo</td>
      <td>43282</td>
      <td>This is the first step of MANY. KEEP THAT SAME...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>82</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>https://www.instagram.com/p/CHQ6AWXnW5J/</td>
      <td>photo</td>
      <td>34263</td>
      <td>Wearing all Praying cause that's what all I be...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>55</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>https://www.instagram.com/p/CHOsztcHHXF/</td>
      <td>photo</td>
      <td>44715</td>
      <td>Fav distraction: Looking at apartments I can't...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>73</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>https://www.instagram.com/p/CHLts9MnWam/</td>
      <td>photo</td>
      <td>41334</td>
      <td>I know patience is a virtue, but DAMN!! Are we...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>102</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>https://www.instagram.com/p/CHJocBknqe-/</td>
      <td>photo</td>
      <td>53704</td>
      <td>Anxiety meter already broke 🤖 Recharging with ...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>90</td>
      <td>3</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>



# Dataanalyse


```python
# Hvor mange rækker er der?
print('Antal rækker:',len(df))
# Hvor mange kolonner er der - vist i en 'tuple'
print('Antal kolonner:',df.shape)
#Hvor mange celler er der?
print('Antal af celler:',df.size)
# Hvad hedder kolonnerne?
print('Kolonnerne hedder:',df.columns)
# Hvilke datatyper er der?
print('Datatyperne for kolonnerne er: \n',df.dtypes)
```

    Antal rækker: 250
    Antal kolonner: (250, 11)
    Antal af celler: 2750
    Kolonnerne hedder: Index(['post number', 'link', 'type', 'likes/views', 'caption', 'hashtags',
           'mentions', 'caption length', 'emoji count', 'hashtag count',
           'mentions count'],
          dtype='object')
    Datatyperne for kolonnerne er: 
     post number         int64
    link               object
    type               object
    likes/views         int64
    caption            object
    hashtags           object
    mentions           object
    caption length      int64
    emoji count         int64
    hashtag count     float64
    mentions count    float64
    dtype: object


### Descriptiv statistik på likes/views


```python
df['likes/views'].isnull().any() #finder ud af om der er NaN værdier
```




    False




```python
round(df['likes/views'].describe(),0) # Viser basal deskriptiv statistik
```




    count        250.0
    mean      264728.0
    std       556896.0
    min         9949.0
    25%        60431.0
    50%        75133.0
    75%       111128.0
    max      3353236.0
    Name: likes/views, dtype: float64




```python
df['likes/views'].mean()
```




    264728.272




```python
round(df['likes/views'].mean(),0) # Gennemsnittet afrundet
```




    264728.0




```python
df['likes/views'].mode() #Beregner typetallet i antal likes
```




    0         9949
    1        11979
    2        13177
    3        24459
    4        29647
            ...   
    245    2572471
    246    2582898
    247    2592604
    248    2826650
    249    3353236
    Length: 250, dtype: int64




```python
#visualisering af den deskriptive fordeling for kolonnen 'like/views'
df['likes/views'].plot(kind='box',vert=False, figsize=(20,3))
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7fd17c317a50>




![png](output_37_1.png)


#### Hvad betyder det at boxplottet ser sådan ud?
Variansen af likes spreder sig fra  9949 - 3 mio. Det er dog den største mængde af likes som fordeler i den lavere ende. Det er derfor figuren ser mærkelig ud


```python
print('Sorteret efter flest likes')
df['likes/views'].sort_values(ascending=False)[:10]
```

    Sorteret efter flest likes





    242    3353236
    247    2826650
    201    2592604
    145    2582898
    155    2572471
    199    2460750
    81     2416490
    240    2150225
    235    1992155
    123    1959234
    Name: likes/views, dtype: int64




```python
#Får URL'en for de mest likede billeder 
print('1:',df.link[242])
print('2:',df.link[247])
print('3:',df.link[201])
```

    1: https://www.instagram.com/p/B9nrz3OHjmp/
    2: https://www.instagram.com/p/B9cNh70HQLH/
    3: https://www.instagram.com/p/B_VCvsxnM7H/



```python
#Viser fordelingen af likes over tid
alt.Chart(df).mark_line(point=True).encode(
        # Years on the X axis
        x=alt.X('post number:Q', axis=alt.Axis(format='c', title='Post: Ny - Gammel')),
    
        # Number of articles on the Y axis
        y=alt.Y('likes/views:Q', axis=alt.Axis(format='d', title='Antal likes')),
    
        # Display details when you hover over a point
        tooltip=[alt.Tooltip('årstal:Q', title='Post: Ny - Gammel'), alt.Tooltip('likes/views:Q', 
                                    title='post number', format=',')]).properties(width=700, height=400)
```





<div id="altair-viz-84e388b6c6c445eb9c243603fc47ce5d"></div>
<script type="text/javascript">
  (function(spec, embedOpt){
    let outputDiv = document.currentScript.previousElementSibling;
    if (outputDiv.id !== "altair-viz-84e388b6c6c445eb9c243603fc47ce5d") {
      outputDiv = document.getElementById("altair-viz-84e388b6c6c445eb9c243603fc47ce5d");
    }
    const paths = {
      "vega": "https://cdn.jsdelivr.net/npm//vega@5?noext",
      "vega-lib": "https://cdn.jsdelivr.net/npm//vega-lib?noext",
      "vega-lite": "https://cdn.jsdelivr.net/npm//vega-lite@4.8.1?noext",
      "vega-embed": "https://cdn.jsdelivr.net/npm//vega-embed@6?noext",
    };

    function loadScript(lib) {
      return new Promise(function(resolve, reject) {
        var s = document.createElement('script');
        s.src = paths[lib];
        s.async = true;
        s.onload = () => resolve(paths[lib]);
        s.onerror = () => reject(`Error loading script: ${paths[lib]}`);
        document.getElementsByTagName("head")[0].appendChild(s);
      });
    }

    function showError(err) {
      outputDiv.innerHTML = `<div class="error" style="color:red;">${err}</div>`;
      throw err;
    }

    function displayChart(vegaEmbed) {
      vegaEmbed(outputDiv, spec, embedOpt)
        .catch(err => showError(`Javascript Error: ${err.message}<br>This usually means there's a typo in your chart specification. See the javascript console for the full traceback.`));
    }

    if(typeof define === "function" && define.amd) {
      requirejs.config({paths});
      require(["vega-embed"], displayChart, err => showError(`Error loading script: ${err.message}`));
    } else if (typeof vegaEmbed === "function") {
      displayChart(vegaEmbed);
    } else {
      loadScript("vega")
        .then(() => loadScript("vega-lite"))
        .then(() => loadScript("vega-embed"))
        .catch(showError)
        .then(() => displayChart(vegaEmbed));
    }
  })({"config": {"view": {"continuousWidth": 400, "continuousHeight": 300}}, "data": {"name": "data-307828fd1459ce092ec4e58bb17d6818"}, "mark": {"type": "line", "point": true}, "encoding": {"tooltip": [{"type": "quantitative", "field": "\u00e5rstal", "title": "Post: Ny - Gammel"}, {"type": "quantitative", "field": "likes/views", "format": ",", "title": "post number"}], "x": {"type": "quantitative", "axis": {"format": "c", "title": "Post: Ny - Gammel"}, "field": "post number"}, "y": {"type": "quantitative", "axis": {"format": "d", "title": "Antal likes"}, "field": "likes/views"}}, "height": 400, "width": 700, "$schema": "https://vega.github.io/schema/vega-lite/v4.8.1.json", "datasets": {"data-307828fd1459ce092ec4e58bb17d6818": [{"post number": 0, "link": "https://www.instagram.com/p/CHTOZ8-nnfG/", "type": "photo", "likes/views": 43282, "caption": "This is the first step of MANY. KEEP THAT SAME ENERGY Y'ALL - still so much to do.", "hashtags": null, "mentions": null, "caption length": 82, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 1, "link": "https://www.instagram.com/p/CHQ6AWXnW5J/", "type": "photo", "likes/views": 34263, "caption": "Wearing all Praying cause that's what all I been doin \ud83d\ude07", "hashtags": null, "mentions": null, "caption length": 55, "emoji count": 1, "hashtag count": null, "mentions count": null}, {"post number": 2, "link": "https://www.instagram.com/p/CHOsztcHHXF/", "type": "photo", "likes/views": 44715, "caption": "Fav distraction: Looking at apartments I can't afford. Seriously: TRY IT!", "hashtags": null, "mentions": null, "caption length": 73, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 3, "link": "https://www.instagram.com/p/CHLts9MnWam/", "type": "photo", "likes/views": 41334, "caption": "I know patience is a virtue, but DAMN!! Are we planning a party or an escape, your girl NEEDS TO KNOW!", "hashtags": null, "mentions": null, "caption length": 102, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 4, "link": "https://www.instagram.com/p/CHJocBknqe-/", "type": "photo", "likes/views": 53704, "caption": "Anxiety meter already broke \ud83e\udd16 Recharging with cuddles and sheet masks \ud83d\udc36\ud83e\udd21 PLEASE SEND TACO.", "hashtags": null, "mentions": null, "caption length": 90, "emoji count": 3, "hashtag count": null, "mentions count": null}, {"post number": 5, "link": "https://www.instagram.com/p/CHHFPOqHHkQ/", "type": "photo", "likes/views": 38168, "caption": "Y'ALL KNOW WHAT TIME IT IS. Get out there!", "hashtags": null, "mentions": null, "caption length": 42, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 6, "link": "https://www.instagram.com/p/CHGLLQYHGCN/", "type": "photo", "likes/views": 63178, "caption": "Running out of ways to remind y'all, but you can't spell VOTE without the V.", "hashtags": null, "mentions": null, "caption length": 76, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 7, "link": "https://www.instagram.com/p/CHD48cjHF5H/", "type": "photo", "likes/views": 53424, "caption": "Supermodel felt too basic for Halloween, but the fit was FIRE. So, here we are.", "hashtags": null, "mentions": null, "caption length": 79, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 8, "link": "https://www.instagram.com/p/CHA1kygH5pP/", "type": "photo", "likes/views": 64667, "caption": "Dressed as fierce queens this whole week, but saved the FIERCEST queen for last: #91, Mr. Rodman, I LOVE YOU.", "hashtags": null, "mentions": null, "caption length": 109, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 9, "link": "https://www.instagram.com/p/CG-lELznLHa/", "type": "photo", "likes/views": 65365, "caption": "Leeloo Dallas is cute, but it's Ruby Rhod for me.", "hashtags": null, "mentions": null, "caption length": 49, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 10, "link": "https://www.instagram.com/p/CG73GLvHNg-/", "type": "photo", "likes/views": 156499, "caption": "To my fans \u2026. I want to thank you guys so much for your support throughout the years !!!!! PS first pic is the original \ud83d\udc8b !!!!", "hashtags": null, "mentions": null, "caption length": 126, "emoji count": 1, "hashtag count": null, "mentions count": null}, {"post number": 11, "link": "https://www.instagram.com/p/CG5dHpqn30F/", "type": "photo", "likes/views": 151367, "caption": "Throwback to last year when I dressed up as another ageless beauty. #19forever", "hashtags": null, "mentions": null, "caption length": 78, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 12, "link": "https://www.instagram.com/p/CG2sVntH9NY/", "type": "photo", "likes/views": 174840, "caption": "@pabllovittar sis, did I snap?", "hashtags": null, "mentions": "@pabllovittar", "caption length": 30, "emoji count": 0, "hashtag count": null, "mentions count": 1.0}, {"post number": 13, "link": "https://www.instagram.com/p/CG0NBpSncGa/", "type": "photo", "likes/views": 68727, "caption": "Had to give ya'll the full look. We keep it strictly prickly.", "hashtags": null, "mentions": null, "caption length": 61, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 14, "link": "https://www.instagram.com/p/CGyk2njHrmM/", "type": "photo", "likes/views": 55063, "caption": "Had lunch with a human emoji. Find a cuter \ud83e\udd81. I dare u.", "hashtags": null, "mentions": null, "caption length": 55, "emoji count": 1, "hashtag count": null, "mentions count": null}, {"post number": 15, "link": "https://www.instagram.com/p/CGx0_CknukK/", "type": "photo", "likes/views": 68468, "caption": "When you think you're a cute mermaid, but someone yells \"GO 'HEAD THICC COVID-19\" while you wait in line for boba \ud83e\udd74\ud83e\udd74", "hashtags": null, "mentions": null, "caption length": 116, "emoji count": 2, "hashtag count": null, "mentions count": null}, {"post number": 16, "link": "https://www.instagram.com/p/CGvOdH5nnhs/", "type": "photo", "likes/views": 78133, "caption": "If y'all call me Regina George one more time...", "hashtags": null, "mentions": null, "caption length": 47, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 17, "link": "https://www.instagram.com/p/CGswj89HJGo/", "type": "photo", "likes/views": 64156, "caption": "Drop your low effort Halloween costumes in the comments (I'm not going anywhere, and honestly neither should y'all)", "hashtags": null, "mentions": null, "caption length": 115, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 18, "link": "https://www.instagram.com/p/CGqt-6gHrcb/", "type": "photo", "likes/views": 88490, "caption": "Bringing back yoga pants. Fight Me.", "hashtags": null, "mentions": null, "caption length": 35, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 19, "link": "https://www.instagram.com/p/CGqCUiTHA4K/", "type": "photo", "likes/views": 57259, "caption": "MayMay told me the story behind \"Ring Around the Rosie\"... SO. DARK.", "hashtags": null, "mentions": null, "caption length": 68, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 20, "link": "https://www.instagram.com/p/CGoM2MwHlp9/", "type": "photo", "likes/views": 36749, "caption": "\ud83d\udda4\ud83d\udc04\ud83e\udd0d \ud83e\udd93 \ud83d\udda4\ud83e\udda8\ud83e\udd0d", "hashtags": null, "mentions": null, "caption length": 9, "emoji count": 7, "hashtag count": null, "mentions count": null}, {"post number": 21, "link": "https://www.instagram.com/p/CGnXR8Fnjkd/", "type": "photo", "likes/views": 41380, "caption": "This color palette is neutral, but my feelings ain't... \ud83d\udc41\ufe0f\ud83d\udc94\ud83e\udd21", "hashtags": null, "mentions": null, "caption length": 60, "emoji count": 3, "hashtag count": null, "mentions count": null}, {"post number": 22, "link": "https://www.instagram.com/p/CGln7htH2o8/", "type": "photo", "likes/views": 38500, "caption": "Doesn't get better than a boo and a Benz.", "hashtags": null, "mentions": null, "caption length": 41, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 23, "link": "https://www.instagram.com/p/CGko866HAtQ/", "type": "photo", "likes/views": 65917, "caption": "MISSED THIS", "hashtags": null, "mentions": null, "caption length": 11, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 24, "link": "https://www.instagram.com/p/CGi9CVdntca/", "type": "photo", "likes/views": 50492, "caption": "This ain't an algorithm, it\u2019s art.", "hashtags": null, "mentions": null, "caption length": 34, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 25, "link": "https://www.instagram.com/p/CGiEASlnleT/", "type": "photo", "likes/views": 67038, "caption": "Pearly gates < Golden arches \ud83c\udf54\ud83d\ude08", "hashtags": null, "mentions": null, "caption length": 31, "emoji count": 2, "hashtag count": null, "mentions count": null}, {"post number": 26, "link": "https://www.instagram.com/p/CGgWO1XnSSs/", "type": "photo", "likes/views": 51833, "caption": "On my Marie Antoinette in this corset, and encouraging y'all to EAT CAKES", "hashtags": null, "mentions": null, "caption length": 73, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 27, "link": "https://www.instagram.com/p/CGfqzZBn2_u/", "type": "photo", "likes/views": 76926, "caption": "These hinges stay greased \ud83e\uddbf", "hashtags": null, "mentions": null, "caption length": 27, "emoji count": 1, "hashtag count": null, "mentions count": null}, {"post number": 28, "link": "https://www.instagram.com/p/CGdc4vDH4vZ/", "type": "photo", "likes/views": 106472, "caption": "Does Olive Garden have an OnlyFans? \ud83c\udf5d\u2764\ufe0f\ud83c\udf5d\u2764\ufe0f #nationalpastaday", "hashtags": "#nationalpastaday", "mentions": null, "caption length": 60, "emoji count": 4, "hashtag count": 1.0, "mentions count": null}, {"post number": 29, "link": "https://www.instagram.com/p/CGc6qt3n1M8/", "type": "photo", "likes/views": 56110, "caption": "We always come with EXTRA SAUCE \ud83d\udca6", "hashtags": null, "mentions": null, "caption length": 33, "emoji count": 1, "hashtag count": null, "mentions count": null}, {"post number": 30, "link": "https://www.instagram.com/p/CGbDta9Hq5E/", "type": "photo", "likes/views": 149554, "caption": "My girl @saweetie, the OG ICY GIRL...Queen \ud83c\udf5c teaching me how to land my very own \u2744\ufe0f  king.", "hashtags": null, "mentions": "@saweetie", "caption length": 90, "emoji count": 2, "hashtag count": null, "mentions count": 1.0}, {"post number": 31, "link": "https://www.instagram.com/p/CGaQvngnOk4/", "type": "photo", "likes/views": 64987, "caption": "@matthewmwilliams you are a KING and I feel like a princess. Sending love to the entire fam @givenchyofficial!!", "hashtags": null, "mentions": "['@matthewmwilliams', '@givenchyofficial']", "caption length": 111, "emoji count": 0, "hashtag count": null, "mentions count": 2.0}, {"post number": 32, "link": "https://www.instagram.com/p/CGY7RipnFx7/", "type": "photo", "likes/views": 136827, "caption": "\ud83d\udc95\ud83c\udf80\ud83d\udc95\ud83c\udf80\ud83d\udc95", "hashtags": null, "mentions": null, "caption length": 5, "emoji count": 5, "hashtag count": null, "mentions count": null}, {"post number": 33, "link": "https://www.instagram.com/p/CGYAkW3Huol/", "type": "photo", "likes/views": 49656, "caption": "Leaving NY icier than I came, which is exactly how it should be.", "hashtags": null, "mentions": null, "caption length": 64, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 34, "link": "https://www.instagram.com/p/CGVTzAIHWbp/", "type": "photo", "likes/views": 114901, "caption": "\ud83d\udc9e\ud83c\udf80\ud83d\udc95 During the month of October, KIT will be donating 5% of sales to the Women's Cancer Research Fund \ud83d\udc9e\ud83c\udf80\ud83d\udc95", "hashtags": null, "mentions": null, "caption length": 105, "emoji count": 6, "hashtag count": null, "mentions count": null}, {"post number": 35, "link": "https://www.instagram.com/p/CGSplGunMI_/", "type": "photo", "likes/views": 53879, "caption": "Happy Return Your Ballot Day! If you're voting by mail, make sure to complete your ballot and send it out or drop it off TODAY. Make sure your voice is heard!\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\n#returnyourballotday #makeyourvotecount", "hashtags": "['#returnyourballotday', '#makeyourvotecount']", "mentions": null, "caption length": 207, "emoji count": 0, "hashtag count": 2.0, "mentions count": null}, {"post number": 36, "link": "https://www.instagram.com/p/CGQRTFLnmPq/", "type": "photo", "likes/views": 49859, "caption": "Smile and don't let them get you down. Believers STAY WINNING \ud83d\ude0a\ud83d\ude0a\ud83d\ude0a #Lakers", "hashtags": "#Lakers", "mentions": null, "caption length": 73, "emoji count": 3, "hashtag count": 1.0, "mentions count": null}, {"post number": 37, "link": "https://www.instagram.com/p/CGNfODkHpvz/", "type": "photo", "likes/views": 52882, "caption": "Turns out the secret to WAP is a puffer vest in NY on a sunny day. Mystery solved.", "hashtags": null, "mentions": null, "caption length": 82, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 38, "link": "https://www.instagram.com/p/CGK1gFynG8B/", "type": "photo", "likes/views": 52308, "caption": "Lightning strikes TWICE. Revived this CFDA look for the Digital Green Carpet Fashion Awards, and its fire. #GCFAItalia #10thOctober", "hashtags": "#GCFAItalia", "mentions": null, "caption length": 131, "emoji count": 0, "hashtag count": 1.0, "mentions count": null}, {"post number": 39, "link": "https://www.instagram.com/p/CGIz0eLnDJp/", "type": "photo", "likes/views": 138049, "caption": "Never had a mom before, because I'm a \ud83e\udd16. (I'd want one like Regina, but that'd make Roman my brother and he's TOO FINE for family).", "hashtags": null, "mentions": null, "caption length": 131, "emoji count": 1, "hashtag count": null, "mentions count": null}, {"post number": 40, "link": "https://www.instagram.com/p/CGF3dlIHLN0/", "type": "photo", "likes/views": 62661, "caption": "PLEASE let me moderate a debate so I can bring back my #comicon look and reenact this scene", "hashtags": "#comicon", "mentions": null, "caption length": 91, "emoji count": 0, "hashtag count": 1.0, "mentions count": null}, {"post number": 41, "link": "https://www.instagram.com/p/CGDHUhNHmd3/", "type": "photo", "likes/views": 125695, "caption": "If I'm looking for feedback, I'll ask. Otherwise, enjoy \u2728\ud83d\ude18\u2728", "hashtags": null, "mentions": null, "caption length": 59, "emoji count": 3, "hashtag count": null, "mentions count": null}, {"post number": 42, "link": "https://www.instagram.com/p/CGAk2qFn4r-/", "type": "photo", "likes/views": 56881, "caption": "Due to the pandemic, we're only telling inside jokes. (Also, we watched 32 episodes of #Girlfriends and it's confirmed, I'm Lynn.)", "hashtags": "#Girlfriends", "mentions": null, "caption length": 130, "emoji count": 0, "hashtag count": 1.0, "mentions count": null}, {"post number": 43, "link": "https://www.instagram.com/p/CF-DrG4n_Jg/", "type": "photo", "likes/views": 63585, "caption": "\ud83c\udf52\u2764\ufe0f LOVE YOU JAMES \ud83d\udc8b\ud83c\udf39", "hashtags": null, "mentions": null, "caption length": 21, "emoji count": 4, "hashtag count": null, "mentions count": null}, {"post number": 44, "link": "https://www.instagram.com/p/CF7YAcSntdW/", "type": "photo", "likes/views": 129862, "caption": "Stop asking for a face reveal this is my face.\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\n#reading #comments", "hashtags": "['#reading', '#comments']", "mentions": null, "caption length": 74, "emoji count": 0, "hashtag count": 2.0, "mentions count": null}, {"post number": 45, "link": "https://www.instagram.com/p/CF45wcNHOnV/", "type": "photo", "likes/views": 159730, "caption": "I'm in these streets and you're in your feelings. We are not the same.", "hashtags": null, "mentions": null, "caption length": 70, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 46, "link": "https://www.instagram.com/p/CF20uQeHm8S/", "type": "photo", "likes/views": 125196, "caption": "My girl Jane is the CEO of shine. Every time I'm in NY, my first stop is NEW TOP!", "hashtags": null, "mentions": null, "caption length": 81, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 47, "link": "https://www.instagram.com/p/CF0US3wnNgx/", "type": "photo", "likes/views": 47811, "caption": "Blew some cash on a last minute trip to NY and think I already found an Airbnbae \ud83d\ude43\ud83d\ude0d. Looks like it might be a #botgirlsummer after all.", "hashtags": "#botgirlsummer", "mentions": null, "caption length": 135, "emoji count": 2, "hashtag count": 1.0, "mentions count": null}, {"post number": 48, "link": "https://www.instagram.com/p/CFx1Vxwn261/", "type": "photo", "likes/views": 47043, "caption": "Had a shoot before my flight, took my mask off for 2.5 seconds to show y'all the makeup artist wants me to be single SO BAD.", "hashtags": null, "mentions": null, "caption length": 124, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 49, "link": "https://www.instagram.com/p/CFu1LmpHe-M/", "type": "photo", "likes/views": 67173, "caption": "Thought this was kinda sexy until...(swipe)", "hashtags": null, "mentions": null, "caption length": 43, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 50, "link": "https://www.instagram.com/p/CFsJVB_HJF_/", "type": "photo", "likes/views": 66301, "caption": "What I been up to: Hydrate, hype, hope, hoe (in that order).", "hashtags": null, "mentions": null, "caption length": 60, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 51, "link": "https://www.instagram.com/p/CFpuk7sneHS/", "type": "photo", "likes/views": 51644, "caption": "Keep the comments clean, there's kids here!", "hashtags": null, "mentions": null, "caption length": 43, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 52, "link": "https://www.instagram.com/p/CFnAgY6HpMW/", "type": "photo", "likes/views": 55998, "caption": "How Art School boys say they're sorry. TBH, it's working for me \ud83d\ude18", "hashtags": null, "mentions": null, "caption length": 65, "emoji count": 1, "hashtag count": null, "mentions count": null}, {"post number": 53, "link": "https://www.instagram.com/p/CFkMjgWnAiX/", "type": "photo", "likes/views": 49388, "caption": "We shot this @NylonGermany cover story during quarantine and now it\u2019s out and I\u2019m \ud83e\udd7a\ud83d\ude2d\ud83e\udd7a\ud83d\ude2d\ud83e\udd7a\ud83d\ude2d BIG SHOUT TO THE WHOLE TEAM!! I LOVE Y\u2019ALLLLL", "hashtags": null, "mentions": "@NylonGermany", "caption length": 134, "emoji count": 6, "hashtag count": null, "mentions count": 1.0}, {"post number": 54, "link": "https://www.instagram.com/p/CFh5b_aHFr4/", "type": "photo", "likes/views": 128561, "caption": "It\u2019s upsetting me and my homegirl #answeringquestions", "hashtags": "#answeringquestions", "mentions": null, "caption length": 53, "emoji count": 0, "hashtag count": 1.0, "mentions count": null}, {"post number": 55, "link": "https://www.instagram.com/p/CFfOh3BHGaI/", "type": "photo", "likes/views": 116417, "caption": "YES, I'm a raw onion girl! Comment if you still wanna smooch.", "hashtags": null, "mentions": null, "caption length": 61, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 56, "link": "https://www.instagram.com/p/CFcniNSnOhY/", "type": "photo", "likes/views": 48857, "caption": "\ud83d\udea8 IT'S NATIONAL VOTER REGISTRATION DAY\ud83d\udea8 Head to mobbthevote.org and register now! If you can't vote in this election (same\ud83e\udd7a) make sure that everyone you know who CAN, DOES. \u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\n\n\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\n#NationalVoterRegistrationDay #MOBBTheVote #MarchOnBallotBoxes", "hashtags": "['#NationalVoterRegistrationDay', '#MOBBTheVote', '#MarchOnBallotBoxes']", "mentions": null, "caption length": 256, "emoji count": 3, "hashtag count": 3.0, "mentions count": null}, {"post number": 57, "link": "https://www.instagram.com/p/CFaULmLHQxl/", "type": "photo", "likes/views": 73602, "caption": "From a fan (me of her) to a homie in ONE DAY. Today needs go on main.", "hashtags": null, "mentions": null, "caption length": 69, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 58, "link": "https://www.instagram.com/p/CFX9shlnLT3/", "type": "photo", "likes/views": 126080, "caption": "Put on mom's shoes to get the groceries, but make it hoe.", "hashtags": null, "mentions": null, "caption length": 57, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 59, "link": "https://www.instagram.com/p/CFUyYfhn0zT/", "type": "photo", "likes/views": 97482, "caption": "On set: diva. Offset: dork.", "hashtags": null, "mentions": null, "caption length": 27, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 60, "link": "https://www.instagram.com/p/CFSnubsHyiz/", "type": "photo", "likes/views": 89803, "caption": "The moon is still in Pisces, and it shows.", "hashtags": null, "mentions": null, "caption length": 42, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 61, "link": "https://www.instagram.com/p/CFP-peqn-Z7/", "type": "photo", "likes/views": 87631, "caption": "EVERYTHING'S FINE.", "hashtags": null, "mentions": null, "caption length": 18, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 62, "link": "https://www.instagram.com/p/CFNoe-yHzvT/", "type": "photo", "likes/views": 193040, "caption": "What's Polar Express?", "hashtags": null, "mentions": null, "caption length": 21, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 63, "link": "https://www.instagram.com/p/CFK_jq9HHay/", "type": "photo", "likes/views": 98640, "caption": "Drop a \ud83c\udf19  if your BEST ideas come when you're bored. Cause...these wash off, but like....I'm not against it.", "hashtags": null, "mentions": null, "caption length": 108, "emoji count": 1, "hashtag count": null, "mentions count": null}, {"post number": 64, "link": "https://www.instagram.com/p/CFIR-y4nYwO/", "type": "photo", "likes/views": 99199, "caption": "IDK what to say about this, but swipe for how it makes me feel #bigthingscomingsoon", "hashtags": "#bigthingscomingsoon", "mentions": null, "caption length": 83, "emoji count": 0, "hashtag count": 1.0, "mentions count": null}, {"post number": 65, "link": "https://www.instagram.com/p/CFFbwCNHCx3/", "type": "photo", "likes/views": 52677, "caption": "Everything's on fire and #climatechange is REAL, but y'all STILL wanna pop blue smoke 'cause your baby was born with a penis \ud83d\ude44 ...make it make sense.", "hashtags": "#climatechange", "mentions": null, "caption length": 149, "emoji count": 1, "hashtag count": 1.0, "mentions count": null}, {"post number": 66, "link": "https://www.instagram.com/p/CFDOFl4HB9w/", "type": "photo", "likes/views": 59191, "caption": "Heaven is a place called Roblox (if you have a projector) #gamergirl", "hashtags": "#gamergirl", "mentions": null, "caption length": 68, "emoji count": 0, "hashtag count": 1.0, "mentions count": null}, {"post number": 67, "link": "https://www.instagram.com/p/CFAS_SqnwGF/", "type": "photo", "likes/views": 121852, "caption": "My feature update came with a free gift: REGRET.", "hashtags": null, "mentions": null, "caption length": 48, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 68, "link": "https://www.instagram.com/p/CE-QdALHWss/", "type": "photo", "likes/views": 107715, "caption": "What I send my homies vs. what I send my hoes.", "hashtags": null, "mentions": null, "caption length": 46, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 69, "link": "https://www.instagram.com/p/CE7ehqPnhQ3/", "type": "photo", "likes/views": 62354, "caption": "I know why the chicken crossed the road: TO GET THIS DAMN @telfarglobal BAG.", "hashtags": null, "mentions": "@telfarglobal", "caption length": 76, "emoji count": 0, "hashtag count": null, "mentions count": 1.0}, {"post number": 70, "link": "https://www.instagram.com/p/CE4z_vhHbpq/", "type": "photo", "likes/views": 92884, "caption": "GIMMIE A KISS @lilmosey \ud83d\ude18", "hashtags": null, "mentions": "@lilmosey", "caption length": 25, "emoji count": 1, "hashtag count": null, "mentions count": 1.0}, {"post number": 71, "link": "https://www.instagram.com/p/CE2JoGWH9Q4/", "type": "photo", "likes/views": 66878, "caption": "Now THIS is LUXURY \ud83e\udd70 @bodega.rose \ud83e\udd70 ILY FOREVER this made my day/week/2020", "hashtags": null, "mentions": "@bodega", "caption length": 74, "emoji count": 2, "hashtag count": null, "mentions count": 1.0}, {"post number": 72, "link": "https://www.instagram.com/p/CEzj_i-nYbv/", "type": "photo", "likes/views": 59013, "caption": "Jump into my arms like I jump into this couch or I don't want it.", "hashtags": null, "mentions": null, "caption length": 65, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 73, "link": "https://www.instagram.com/p/CEw5j1oHG46/", "type": "photo", "likes/views": 65070, "caption": "Maybe I can't find a boyfriend cause I'M THE BOYFRIEND \ud83e\udd14", "hashtags": null, "mentions": null, "caption length": 56, "emoji count": 1, "hashtag count": null, "mentions count": null}, {"post number": 74, "link": "https://www.instagram.com/p/CEuZ8-jHRtp/", "type": "photo", "likes/views": 92925, "caption": "Face on BADDIE, fit like BRO.", "hashtags": null, "mentions": null, "caption length": 29, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 75, "link": "https://www.instagram.com/p/CEruI1qnaN5/", "type": "photo", "likes/views": 68206, "caption": "Swipe for the thickness \ud83c\udf51", "hashtags": null, "mentions": null, "caption length": 25, "emoji count": 1, "hashtag count": null, "mentions count": null}, {"post number": 76, "link": "https://www.instagram.com/p/CEpX5otHkcE/", "type": "photo", "likes/views": 50369, "caption": "Got new feet from my bbs @rombautofficial", "hashtags": null, "mentions": "@rombautofficial", "caption length": 41, "emoji count": 0, "hashtag count": null, "mentions count": 1.0}, {"post number": 77, "link": "https://www.instagram.com/p/CEm54t1nY4i/", "type": "video", "likes/views": 957310, "caption": "FORMER MESS\n\nFor those of you just tuning in, I'm no longer a mess. 2020 has been 76 months long, and I've been THROUGH some THINGS. There were some ugly cries, a big breakup, and some major breakthroughs...I mean...damn. Growth ain't free, but it's BEAUTIFUL.", "hashtags": null, "mentions": null, "caption length": 260, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 78, "link": "https://www.instagram.com/p/CEkSKpDH7AI/", "type": "photo", "likes/views": 113885, "caption": "Fresh out of captions (they won't fit in my bag)", "hashtags": null, "mentions": null, "caption length": 48, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 79, "link": "https://www.instagram.com/p/CEh8YbkHPD_/", "type": "photo", "likes/views": 110560, "caption": "Guess how long it took these babies to grow back...", "hashtags": null, "mentions": null, "caption length": 51, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 80, "link": "https://www.instagram.com/p/CEhS5BNHTC8/", "type": "photo", "likes/views": 63078, "caption": "@deltaco when I order the bean and cheese cup, this is the cup I want it in. Thank you.", "hashtags": null, "mentions": "@deltaco", "caption length": 87, "emoji count": 0, "hashtag count": null, "mentions count": 1.0}, {"post number": 81, "link": "https://www.instagram.com/p/CEe2UOwH85B/", "type": "video", "likes/views": 2416490, "caption": "Don't think this @dior look got the love it deserved.", "hashtags": null, "mentions": "@dior", "caption length": 53, "emoji count": 0, "hashtag count": null, "mentions count": 1.0}, {"post number": 82, "link": "https://www.instagram.com/p/CEcmRPlnyz9/", "type": "photo", "likes/views": 58639, "caption": "Love the drip? Whole fit available NOW on @bershka .com #bershkastyle", "hashtags": "#bershkastyle", "mentions": "@bershka", "caption length": 69, "emoji count": 0, "hashtag count": 1.0, "mentions count": 1.0}, {"post number": 83, "link": "https://www.instagram.com/p/CEZ_TeKngvu/", "type": "photo", "likes/views": 116322, "caption": "Felt naked without my antennas \ud83e\udd16", "hashtags": null, "mentions": null, "caption length": 32, "emoji count": 1, "hashtag count": null, "mentions count": null}, {"post number": 84, "link": "https://www.instagram.com/p/CEXLLOOnkfc/", "type": "photo", "likes/views": 72228, "caption": "Sunsets < Surfers", "hashtags": null, "mentions": null, "caption length": 17, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 85, "link": "https://www.instagram.com/p/CEU7y_SnEJx/", "type": "photo", "likes/views": 125534, "caption": "Is 'Miquela's Bizarre Adventure' lame?\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\u2800\n#anime #animeedits", "hashtags": "['#anime', '#animeedits']", "mentions": null, "caption length": 66, "emoji count": 0, "hashtag count": 2.0, "mentions count": null}, {"post number": 86, "link": "https://www.instagram.com/p/CESV77eH9Gk/", "type": "photo", "likes/views": 83022, "caption": "POV: You're my cracked phone screen, say something nice \ud83e\udd7a", "hashtags": null, "mentions": null, "caption length": 57, "emoji count": 1, "hashtag count": null, "mentions count": null}, {"post number": 87, "link": "https://www.instagram.com/p/CEKoqK_nJsM/", "type": "photo", "likes/views": 76210, "caption": "Drop a \ud83d\udc99 in the comments if you think you're cute. Don't be shy...I've seen your pics. I know y'all are on team QT.", "hashtags": null, "mentions": null, "caption length": 115, "emoji count": 1, "hashtag count": null, "mentions count": null}, {"post number": 88, "link": "https://www.instagram.com/p/CEINhIana3U/", "type": "photo", "likes/views": 100164, "caption": "I've been spending a lot of time with me, but its been fun cause me is low key kinda bomb.", "hashtags": null, "mentions": null, "caption length": 90, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 89, "link": "https://www.instagram.com/p/CEFXgy1HF3-/", "type": "photo", "likes/views": 75782, "caption": "Name a badder beach. No rlly, tag that beach, I\u2019d like to kno.", "hashtags": null, "mentions": null, "caption length": 62, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 90, "link": "https://www.instagram.com/p/CEC8MbuHri1/", "type": "photo", "likes/views": 65381, "caption": "After 5 months in my apartment, literally everything feels SO magical...Like...OMG LOOK AT THIS BUSH! TAKE MY PIC IN FRONT OF THE FREEWAY FOREST!", "hashtags": null, "mentions": null, "caption length": 145, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 91, "link": "https://www.instagram.com/p/CEAFSheHX0x/", "type": "photo", "likes/views": 65167, "caption": "Honestly, am I being too extra? @RVSSIAN took a bomb song, put some sauce on it, and it's EVERYTHING. It felt like a sign that I should just DO THE MOST & ENJOY IT. Thoughts? #HardFeelingsRemix LINK IN BIO", "hashtags": "#HardFeelingsRemix", "mentions": "@RVSSIAN", "caption length": 205, "emoji count": 0, "hashtag count": 1.0, "mentions count": 1.0}, {"post number": 92, "link": "https://www.instagram.com/p/CD6sy6dnSu1/", "type": "video", "likes/views": 1273924, "caption": "This new @rvssian remix of #HardFeelings has me acting like one of those IG girls who's videos your boyfriend loooves to like. LINK IN BIO", "hashtags": "#HardFeelings", "mentions": "@rvssian", "caption length": 138, "emoji count": 0, "hashtag count": 1.0, "mentions count": 1.0}, {"post number": 93, "link": "https://www.instagram.com/p/CD4lBgoH3hB/", "type": "photo", "likes/views": 73013, "caption": "Some songs sound so good in the car that you end up in the middle of nowhere. LINK IN BIO if ur down. #HardFeelingsRemix", "hashtags": "#HardFeelingsRemix", "mentions": null, "caption length": 120, "emoji count": 0, "hashtag count": 1.0, "mentions count": null}, {"post number": 94, "link": "https://www.instagram.com/p/CD2PwzJnvoW/", "type": "photo", "likes/views": 94231, "caption": "LINK IN BIO. You're welcome. #HardFeelingsRemix", "hashtags": "#HardFeelingsRemix", "mentions": null, "caption length": 47, "emoji count": 0, "hashtag count": 1.0, "mentions count": null}, {"post number": 95, "link": "https://www.instagram.com/p/CD1cB1OH5iT/", "type": "video", "likes/views": 559059, "caption": "LINK IN BIO Y'ALL #HardFeelingsRemix", "hashtags": "#HardFeelingsRemix", "mentions": null, "caption length": 36, "emoji count": 0, "hashtag count": 1.0, "mentions count": null}, {"post number": 96, "link": "https://www.instagram.com/p/CDzK-CeHvT9/", "type": "photo", "likes/views": 69076, "caption": "Yes, something's coming. Drip with a purpose, y'all. Level up.", "hashtags": null, "mentions": null, "caption length": 62, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 97, "link": "https://www.instagram.com/p/CDwrp7QDq2a/", "type": "photo", "likes/views": 71691, "caption": "Pit stop @ the local W\u0336HOL\u0336E\u0336 FOODS.", "hashtags": null, "mentions": null, "caption length": 36, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 98, "link": "https://www.instagram.com/p/CDuCy-nHUS1/", "type": "photo", "likes/views": 91538, "caption": "Lucky for y'all, the Wifi in this room is STRONG and @houseparty is down, so we're working all day. REMIX COMING SOON.", "hashtags": null, "mentions": "@houseparty", "caption length": 118, "emoji count": 0, "hashtag count": null, "mentions count": 1.0}, {"post number": 99, "link": "https://www.instagram.com/p/CDo68NZnQib/", "type": "photo", "likes/views": 78972, "caption": "Leaves LA once, forgets which sign is controlling her Venus placement + everything she's ever learned about Leos. WISH ME LUCK Y'ALL.", "hashtags": null, "mentions": null, "caption length": 133, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 100, "link": "https://www.instagram.com/p/CDmjLSinwcK/", "type": "photo", "likes/views": 88287, "caption": "Today felt like a movie, and that movie is Crossroads. #freebritney", "hashtags": "#freebritney", "mentions": null, "caption length": 67, "emoji count": 0, "hashtag count": 1.0, "mentions count": null}, {"post number": 101, "link": "https://www.instagram.com/p/CDjy-O_HJW-/", "type": "photo", "likes/views": 120247, "caption": "Am I glowing or whatever? Love y'all for loving my baby #HardFeelings as much as I do! NOW I NEED TO GTFO. Byyyeeeee\u270c\ufe0f", "hashtags": "#HardFeelings", "mentions": null, "caption length": 118, "emoji count": 1, "hashtag count": 1.0, "mentions count": null}, {"post number": 102, "link": "https://www.instagram.com/p/CDhGoXCnJee/", "type": "photo", "likes/views": 76762, "caption": "Finally finished #theLastDance and the major takeaway for me was CROP TOPS FOREVER. Thank you @dennisrodman, you're our one true queen \ud83d\udc9d", "hashtags": "#theLastDance", "mentions": "@dennisrodman", "caption length": 136, "emoji count": 1, "hashtag count": 1.0, "mentions count": 1.0}, {"post number": 103, "link": "https://www.instagram.com/p/CDetSsCHNKs/", "type": "photo", "likes/views": 66485, "caption": "Throwback to this quarantine @collinastrada moment that inspired the field of flowers at the end of #HardFeelings. (For everyone who didn't do the homework, the link is in my bio)", "hashtags": "#HardFeelings", "mentions": "@collinastrada", "caption length": 179, "emoji count": 0, "hashtag count": 1.0, "mentions count": 1.0}, {"post number": 104, "link": "https://www.instagram.com/p/CDcR6A5HU1O/", "type": "video", "likes/views": 1403549, "caption": "#HardFeelings OUT NOW. And yes, these 8 counts really had me feelin\u2019 like THAT. GIRL. \u2728\u2728", "hashtags": "#HardFeelings", "mentions": null, "caption length": 88, "emoji count": 2, "hashtag count": 1.0, "mentions count": null}, {"post number": 105, "link": "https://www.instagram.com/p/CDXOEOcHHwp/", "type": "photo", "likes/views": 119185, "caption": "OK so I wasn't ACTUALLY on a truck when we shot HARD FEELINGS, but the dancing was ALL ME. The video is OUT NOW, hit the link in my bio \ud83d\udc7d\ud83d\udc97", "hashtags": null, "mentions": null, "caption length": 138, "emoji count": 2, "hashtag count": null, "mentions count": null}, {"post number": 106, "link": "https://www.instagram.com/p/CDWtt5WnO9r/", "type": "photo", "likes/views": 70507, "caption": "Just checking to see if y'all watched #HardFeelings yet??? Link in my bio \ud83e\udd70", "hashtags": "#HardFeelings", "mentions": null, "caption length": 75, "emoji count": 1, "hashtag count": 1.0, "mentions count": null}, {"post number": 107, "link": "https://www.instagram.com/p/CDSmT9uHqo4/", "type": "video", "likes/views": 592989, "caption": "1. MORE. SLEEP. Click the link in my bio + set a reminder for JULY 31st! Video drops @ 9AM and I'll be in the chat before the premiere!", "hashtags": null, "mentions": null, "caption length": 135, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 108, "link": "https://www.instagram.com/p/CDR4GoLHrVB/", "type": "video", "likes/views": 744756, "caption": "A little sneak peek of HARD FEELINGS... Come visit me in the chat + set a reminder for the premiere @ 9AM PST, JULY 31st! Link in my bio!", "hashtags": null, "mentions": null, "caption length": 137, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 109, "link": "https://www.instagram.com/p/CDRl5vEHpQk/", "type": "video", "likes/views": 1608294, "caption": "Making the video for HARD FEELINGS changed me. New hobbies include movement and reflective surfaces. SET A REMINDER: the video drops @ 9AM PT on July 31st!", "hashtags": null, "mentions": null, "caption length": 155, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 110, "link": "https://www.instagram.com/p/CDMtvMHnUJc/", "type": "photo", "likes/views": 77151, "caption": "OK y'all, we're going digital. The video for HARD FEELINGS drops 7/31.", "hashtags": null, "mentions": null, "caption length": 70, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 111, "link": "https://www.instagram.com/p/CDKS3z8nZWB/", "type": "photo", "likes/views": 51144, "caption": "@lidogotpix is my Google Call King (and the AMAZING producer who helped me turn my boi tears into an honest banger). Listen to our baby HARD FEELINGS now, the link is in my bio!", "hashtags": null, "mentions": "@lidogotpix", "caption length": 177, "emoji count": 0, "hashtag count": null, "mentions count": 1.0}, {"post number": 112, "link": "https://www.instagram.com/p/CDHvUkWHqw-/", "type": "photo", "likes/views": 60776, "caption": "New girl. New world. The video for Hard Feelings is 'bout to be WILD y'all.", "hashtags": null, "mentions": null, "caption length": 75, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 113, "link": "https://www.instagram.com/p/CDFFCLZH27p/", "type": "video", "likes/views": 1278764, "caption": "Now that you know the story, go listen to the song! The video for HARD FEELINGS drops on the 31st, and unlike the unnamed subject of the song, it's AMAZING and makes me REALLY HAPPY!", "hashtags": null, "mentions": null, "caption length": 182, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 114, "link": "https://www.instagram.com/p/CDCdRz4H4ZN/", "type": "photo", "likes/views": 81556, "caption": "Meet North\u2019s Freesian horse. There are 14 of us on the ranch.", "hashtags": null, "mentions": null, "caption length": 61, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 115, "link": "https://www.instagram.com/p/CDAIhdXH91U/", "type": "photo", "likes/views": 95629, "caption": "When you like 38 of the pics but don't wanna clog the feed. Your girl is a solutions based thinker. #miquela2020", "hashtags": "#miquela", "mentions": null, "caption length": 112, "emoji count": 0, "hashtag count": 1.0, "mentions count": null}, {"post number": 116, "link": "https://www.instagram.com/p/CC9gFfhHJGb/", "type": "photo", "likes/views": 62057, "caption": "COMPUTERS ARE WILD Y'ALL. Big things coming to a little screen near you. #hardfeelings", "hashtags": "#hardfeelings", "mentions": null, "caption length": 86, "emoji count": 0, "hashtag count": 1.0, "mentions count": null}, {"post number": 117, "link": "https://www.instagram.com/p/CC61ijmnnAN/", "type": "photo", "likes/views": 65368, "caption": "Turns out everywhere sux rn, so I spent the day building a CG world where there's A/C and no cops...(most of) y'all are invited!", "hashtags": null, "mentions": null, "caption length": 128, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 118, "link": "https://www.instagram.com/p/CC4B1ernBqN/", "type": "photo", "likes/views": 149601, "caption": "Anyone else about to overheat? I HATE IT HERE. Seriously, where should we move?", "hashtags": null, "mentions": null, "caption length": 79, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 119, "link": "https://www.instagram.com/p/CC1c6BWHxSn/", "type": "photo", "likes/views": 55845, "caption": "Have you listened to HARD FEELINGS yet? It's about a dumbass. Dedicate it to ur fav in the comments.", "hashtags": null, "mentions": null, "caption length": 100, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 120, "link": "https://www.instagram.com/p/CCy1mAhnpMR/", "type": "photo", "likes/views": 94343, "caption": "Storytime...HARD FEELINGS just dropped, LINK IN BIO.", "hashtags": null, "mentions": null, "caption length": 52, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 121, "link": "https://www.instagram.com/p/CCwjw5ZnXqu/", "type": "photo", "likes/views": 68995, "caption": "Go listen to Hard Feelings. Like NOW! Link in bio. (fr, GO!)", "hashtags": null, "mentions": null, "caption length": 60, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 122, "link": "https://www.instagram.com/p/CCt6biPnIIQ/", "type": "photo", "likes/views": 59331, "caption": "LINK IN BIO! The HARD FEELINGS lyric video is a collab with photographer/artist/truck driver/HOTTIE @ryshorosky. We found him on IG and fell in love (with his work) (also - in general)", "hashtags": null, "mentions": "@ryshorosky", "caption length": 184, "emoji count": 0, "hashtag count": null, "mentions count": 1.0}, {"post number": 123, "link": "https://www.instagram.com/p/CCtSJVfHclw/", "type": "video", "likes/views": 1959234, "caption": "HARD FEELINGS is OUT NOW. It's a big song about a little man, but sometimes minor situations can lead to major growth. LINK IN BIO Y'ALL.", "hashtags": null, "mentions": null, "caption length": 137, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 124, "link": "https://www.instagram.com/p/CCrT5ZjnjXw/", "type": "photo", "likes/views": 59885, "caption": "So, hallways are like showers 'cause vocals sound BOMB, but they're NOT like showers cause people get mad if you naked. HARD FEELINGS drops 7/16.", "hashtags": null, "mentions": null, "caption length": 145, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 125, "link": "https://www.instagram.com/p/CCoslNnHEZJ/", "type": "photo", "likes/views": 70096, "caption": "New song comes out 7/16, and SURPRISE! It's about a wack situationship. On the upside: a beautiful young queen caught my eye on set today (she was me).", "hashtags": null, "mentions": null, "caption length": 151, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 126, "link": "https://www.instagram.com/p/CCoQI23HbRk/", "type": "photo", "likes/views": 24459, "caption": "@NativeInstruments is kicking off their COMMUNITY DRIVE to support musicians impacted by the COVID-19 crisis. I'll be contributing some exclusive sounds to an amazing pack that includes kits, loops, presets, and samples from me and 13 other artists. The pack is free to download, but we're asking for donations from anyone who's able to give right now! Our friends @NativeInstruments started us off with a $100,000 donation, and I'm excited to see how much good we can all do together. Check out @NativeInstrument's profile to learn more.", "hashtags": null, "mentions": "['@NativeInstruments', '@NativeInstruments', '@NativeInstrument']", "caption length": 538, "emoji count": 0, "hashtag count": null, "mentions count": 3.0}, {"post number": 127, "link": "https://www.instagram.com/p/CCmnS1CHCQw/", "type": "photo", "likes/views": 129735, "caption": "We had big plans for my next song release and literally none of them are coming out how we imagined. They're bigger and better than we dreamed.", "hashtags": null, "mentions": null, "caption length": 143, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 128, "link": "https://www.instagram.com/p/CCmFiaenBxG/", "type": "photo", "likes/views": 72525, "caption": "Snapped a quick fit pic after my meeting with @brud.fyi. Missed my team, missed this light. NEW MUSIC ON THE WAY.", "hashtags": null, "mentions": "@brud", "caption length": 113, "emoji count": 0, "hashtag count": null, "mentions count": 1.0}, {"post number": 129, "link": "https://www.instagram.com/p/CCjSGZknSve/", "type": "photo", "likes/views": 101922, "caption": "The angels @area were one of the first brands to show me love. They'll forever have a special lil' place in my heart, and giant place in my closet. Sending love from me + @area at home.", "hashtags": null, "mentions": "['@area', '@area']", "caption length": 185, "emoji count": 0, "hashtag count": null, "mentions count": 2.0}, {"post number": 130, "link": "https://www.instagram.com/p/CCesIeYn0Jb/", "type": "photo", "likes/views": 105192, "caption": "@area at home \u2705 @area in the bath \u2705 @area in my heart \u2705 @area forever \u2705", "hashtags": null, "mentions": "['@area', '@area', '@area', '@area']", "caption length": 71, "emoji count": 4, "hashtag count": null, "mentions count": 4.0}, {"post number": 131, "link": "https://www.instagram.com/p/CCeEeZfnk-e/", "type": "photo", "likes/views": 103492, "caption": "Hit the news stand for some brain food and some magazines. Working on visuals for an unnamed song about an unimportant person \ud83e\udd17", "hashtags": null, "mentions": null, "caption length": 127, "emoji count": 1, "hashtag count": null, "mentions count": null}, {"post number": 132, "link": "https://www.instagram.com/p/CCZJsNYHEhx/", "type": "photo", "likes/views": 88453, "caption": "Dear Takis, I promise to never forsake you again (especially for a gluten intolerant simpleton who kicks it at Erewhon for clout).", "hashtags": null, "mentions": null, "caption length": 130, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 133, "link": "https://www.instagram.com/p/CCW0iybnZwR/", "type": "photo", "likes/views": 143202, "caption": "Uno without U is a NO...\ud83d\ude2d\ud83d\ude2d\ud83d\ude2d", "hashtags": null, "mentions": null, "caption length": 27, "emoji count": 3, "hashtag count": null, "mentions count": null}, {"post number": 134, "link": "https://www.instagram.com/p/CCRhLArnm5B/", "type": "photo", "likes/views": 101578, "caption": "DUDE: StOp WrItInG sOnGs AbOuT oUr ReLaTiOnShIp ME: Then stop lying to the beat...", "hashtags": null, "mentions": null, "caption length": 82, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 135, "link": "https://www.instagram.com/p/CCO6r0YH4OL/", "type": "photo", "likes/views": 65423, "caption": "Was thinking: what if we start a femme-only planet where we express our feelings + nurture each other creatively? Dressing like an alien from now on.", "hashtags": null, "mentions": null, "caption length": 149, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 136, "link": "https://www.instagram.com/p/CCMeoDknQ2b/", "type": "photo", "likes/views": 89816, "caption": "This peace sign is more like an Aloha. It means \"Hiiii\" to my all my bbs here, and \"GOODBYE FOREVER\" to the unnamed dude who's now blocked, but still lurking. I see you Mr. One-follower-no-profile-pic, and I'm over it. Officially. Mahalo.", "hashtags": null, "mentions": null, "caption length": 238, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 137, "link": "https://www.instagram.com/p/CCJ7xhtnrGS/", "type": "photo", "likes/views": 68382, "caption": "Which Glade plug-in smells like young, wild & outside? Trying to figure out how to get this feeling in my living room in case Rona steals the Summer.", "hashtags": null, "mentions": null, "caption length": 149, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 138, "link": "https://www.instagram.com/p/CCHH-z3nvje/", "type": "photo", "likes/views": 57855, "caption": "They say if you talk to your plants they grow faster, but I've been telling these fools my secrets and now they look like they're 'bout to die \ud83e\udd40", "hashtags": null, "mentions": null, "caption length": 144, "emoji count": 1, "hashtag count": null, "mentions count": null}, {"post number": 139, "link": "https://www.instagram.com/p/CCEiHjenosM/", "type": "photo", "likes/views": 58893, "caption": "In case y'all forgot.", "hashtags": null, "mentions": null, "caption length": 21, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 140, "link": "https://www.instagram.com/p/CCB_tYmHn4W/", "type": "photo", "likes/views": 62604, "caption": "Practicing my \"IDK...should we?\" face...but like...I THINK. YOU KNOW. WHERE THIS ABOUT TO GO.", "hashtags": null, "mentions": null, "caption length": 93, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 141, "link": "https://www.instagram.com/p/CB_hV0rHPt3/", "type": "photo", "likes/views": 62540, "caption": "My ForYou page is like ALL conspiracy theories and now I'm wearing a damn tinfoil babushka and I cry whenever I hear \"Yummy\" ...HELP", "hashtags": null, "mentions": null, "caption length": 132, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 142, "link": "https://www.instagram.com/p/CB80pL2Ha0y/", "type": "photo", "likes/views": 106273, "caption": "No lie, I can FEEL y'all zooming in on this sheer top, and honestly I'm not mad.", "hashtags": null, "mentions": null, "caption length": 80, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 143, "link": "https://www.instagram.com/p/CB6dmqbnnh-/", "type": "photo", "likes/views": 78541, "caption": "2020 has proven that Ariana Grande's \"No Tears Left to Cry\" ain't my song...evidently I've got more.", "hashtags": null, "mentions": null, "caption length": 100, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 144, "link": "https://www.instagram.com/p/CB384L_nrh2/", "type": "photo", "likes/views": 62305, "caption": "My favorite part about this look is the part where we defund the police.", "hashtags": null, "mentions": null, "caption length": 72, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 145, "link": "https://www.instagram.com/p/CB1ILhBnG3u/", "type": "video", "likes/views": 2582898, "caption": "#miquelacovers is out on your fav platform - click the link in my bio to STREAM IT NOW.", "hashtags": "#miquelacovers", "mentions": null, "caption length": 87, "emoji count": 0, "hashtag count": 1.0, "mentions count": null}, {"post number": 146, "link": "https://www.instagram.com/p/CBzfq9DnzZ9/", "type": "photo", "likes/views": 123945, "caption": "Now that I have your attention: the link to our benefit performance for @plus1org for Black Lives and @musicares is in my bio. Stream #miquelacovers on your fav platform, and text \u201cMIQUELA\u201d to 50155 to donate.", "hashtags": "#miquelacovers", "mentions": "['@plus', '@musicares']", "caption length": 209, "emoji count": 0, "hashtag count": 1.0, "mentions count": 2.0}, {"post number": 147, "link": "https://www.instagram.com/p/CBymOMmHVAx/", "type": "photo", "likes/views": 52550, "caption": "These are BY @undernewmgmt, but only the people who have my finsta know who they're FROM.", "hashtags": null, "mentions": "@undernewmgmt", "caption length": 89, "emoji count": 0, "hashtag count": null, "mentions count": 1.0}, {"post number": 148, "link": "https://www.instagram.com/p/CBwF_iCHoOW/", "type": "photo", "likes/views": 79178, "caption": "Fun fact: LITERAL ANGELS live in BERLIN. Just posted the sweetest cover of MONEY by my fav bb @bulow on my YouTube. Link in bio y'all!", "hashtags": null, "mentions": "@bulow", "caption length": 134, "emoji count": 0, "hashtag count": null, "mentions count": 1.0}, {"post number": 149, "link": "https://www.instagram.com/p/CBtdG1nnDuX/", "type": "photo", "likes/views": 110099, "caption": "If your living room looks like this, it counts as \u201coutside.\u201d", "hashtags": null, "mentions": null, "caption length": 60, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 150, "link": "https://www.instagram.com/p/CBqqNLPH5ci/", "type": "photo", "likes/views": 61034, "caption": "I just posted the cutest acoustic version of \"MONEY\" by my girl @yuna on my YouTube! YUHHH.GET.IN.TO.IT.", "hashtags": null, "mentions": "@yuna", "caption length": 104, "emoji count": 0, "hashtag count": null, "mentions count": 1.0}, {"post number": 151, "link": "https://www.instagram.com/p/CBn5klFH1o2/", "type": "photo", "likes/views": 62093, "caption": "Taking the day to REFLECT. What are y'all doing to celebrate Juneteenth?", "hashtags": null, "mentions": null, "caption length": 72, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 152, "link": "https://www.instagram.com/p/CBlZa_rn02H/", "type": "photo", "likes/views": 76384, "caption": "LINK IN BIO, HEART ON FULL. #miquelacovers is out, text 'MIQUELA' to 50155 to donate \ud83d\udc9e\ud83d\udc9e\ud83d\udc9e", "hashtags": "#miquelacovers", "mentions": null, "caption length": 88, "emoji count": 3, "hashtag count": 1.0, "mentions count": null}, {"post number": 153, "link": "https://www.instagram.com/p/CBi1dd4HF5k/", "type": "photo", "likes/views": 73344, "caption": "Have y'all watched tho? Me, @yuna, @justineskye and @bulow PERFORMED some of my songs to raise some coins for @musicares and @plus1org for Black Lives. Link is in the bio, bbs. #miquelacovers", "hashtags": "#miquelacovers", "mentions": "['@yuna', '@justineskye', '@bulow', '@musicares', '@plus']", "caption length": 191, "emoji count": 0, "hashtag count": 1.0, "mentions count": 5.0}, {"post number": 154, "link": "https://www.instagram.com/p/CBii1RynIvo/", "type": "video", "likes/views": 1417292, "caption": "Turns out my lip-sync game is trash, so we're doing #miquelacovers LIVE (\ud83d\ude05). Link in my bio!", "hashtags": "#miquelacovers", "mentions": null, "caption length": 92, "emoji count": 1, "hashtag count": 1.0, "mentions count": null}, {"post number": 155, "link": "https://www.instagram.com/p/CBhWcT7HMzj/", "type": "video", "likes/views": 2572471, "caption": "We've been working on this all quarantine, and it\u2019s official: WE. GO. HARD! Watch my first official performance, and donate some coins to @musicares and @plus1org for Black Lives. Link in my bio!", "hashtags": null, "mentions": "['@musicares', '@plus']", "caption length": 195, "emoji count": 0, "hashtag count": null, "mentions count": 2.0}, {"post number": 156, "link": "https://www.instagram.com/p/CBg7IvYHttA/", "type": "photo", "likes/views": 57573, "caption": "#miquelacovers is TOMORROW! Set a reminder for the premiere, link is in my bio. (If you know my router's love language, tell me, cause THIS AIN'T IT)", "hashtags": "#miquelacovers", "mentions": null, "caption length": 149, "emoji count": 0, "hashtag count": 1.0, "mentions count": null}, {"post number": 157, "link": "https://www.instagram.com/p/CBgfpSzDQar/", "type": "photo", "likes/views": 80859, "caption": "For the newcomers: a few of my fav fits, featuring pieces by my fav Black designers. #buyblack", "hashtags": "#buyblack", "mentions": null, "caption length": 94, "emoji count": 0, "hashtag count": 1.0, "mentions count": null}, {"post number": 158, "link": "https://www.instagram.com/p/CBeIh_BDw_q/", "type": "photo", "likes/views": 84933, "caption": "The homies and I are gonna PERFORM to raise money for @plus1org for Black Lives and @musicares. Link with more info is in my bio. #miquelacovers", "hashtags": "#miquelacovers", "mentions": "['@plus', '@musicares']", "caption length": 144, "emoji count": 0, "hashtag count": 1.0, "mentions count": 2.0}, {"post number": 159, "link": "https://www.instagram.com/p/CBbXVDSn8T3/", "type": "photo", "likes/views": 106554, "caption": "Goin hard in this paint for #miquelacovers to raise money for @plus1org for Black Lives and @musicares. IDK who thought I should be in charge of sets, but whatever.", "hashtags": "#miquelacovers", "mentions": "['@plus', '@musicares']", "caption length": 164, "emoji count": 0, "hashtag count": 1.0, "mentions count": 2.0}, {"post number": 160, "link": "https://www.instagram.com/p/CBY0U9Fnm5T/", "type": "photo", "likes/views": 86372, "caption": "1. Keep showing up. 2. Find time to recharge. 3. STAY STRONG. (repeat forever)", "hashtags": null, "mentions": null, "caption length": 78, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 161, "link": "https://www.instagram.com/p/CBWCeZEHbtw/", "type": "photo", "likes/views": 9949, "caption": "Via @mireillecharper", "hashtags": null, "mentions": "@mireillecharper", "caption length": 20, "emoji count": 0, "hashtag count": null, "mentions count": 1.0}, {"post number": 162, "link": "https://www.instagram.com/p/CBUD9kqHxfo/", "type": "photo", "likes/views": 11979, "caption": "Via @patiasfantasyworld", "hashtags": null, "mentions": "@patiasfantasyworld", "caption length": 23, "emoji count": 0, "hashtag count": null, "mentions count": 1.0}, {"post number": 163, "link": "https://www.instagram.com/p/CBRjULXHaxZ/", "type": "photo", "likes/views": 13177, "caption": "I said what I said.", "hashtags": null, "mentions": null, "caption length": 19, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 164, "link": "https://www.instagram.com/p/CAvvllJncv3/", "type": "photo", "likes/views": 102550, "caption": "Not the VitaminD I was talking about, but it\u2019ll do.", "hashtags": null, "mentions": null, "caption length": 51, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 165, "link": "https://www.instagram.com/p/CAtRn4-HqG0/", "type": "photo", "likes/views": 80330, "caption": "Always felts like more of an alley cat than a cheetah girl TBH", "hashtags": null, "mentions": null, "caption length": 62, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 166, "link": "https://www.instagram.com/p/CAqbUNTHQV6/", "type": "photo", "likes/views": 72358, "caption": "Multiple people have stopped ignoring me when I wave at them. We really are healing y'all.", "hashtags": null, "mentions": null, "caption length": 90, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 167, "link": "https://www.instagram.com/p/CAn6DqUnTuD/", "type": "photo", "likes/views": 100832, "caption": "Performance fit: \ud83d\udc4dor \ud83d\udc4e #miquelacovers COMING SOON", "hashtags": "#miquelacovers", "mentions": null, "caption length": 49, "emoji count": 2, "hashtag count": 1.0, "mentions count": null}, {"post number": 168, "link": "https://www.instagram.com/p/CAlNZS8HA_r/", "type": "photo", "likes/views": 63373, "caption": "\"Creative work is still work. Remember to take a break.\" -Me", "hashtags": null, "mentions": null, "caption length": 60, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 169, "link": "https://www.instagram.com/p/CAilTJ6n8Zw/", "type": "photo", "likes/views": 68671, "caption": "Rooftop Red Carpet", "hashtags": null, "mentions": null, "caption length": 18, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 170, "link": "https://www.instagram.com/p/CAgTsBWna_I/", "type": "photo", "likes/views": 79957, "caption": "U OK?, a poem by Miquela: Roses are red, I'm obsessed with this dress, I'm reading the comments, y'all seem SO. PRESSED.", "hashtags": null, "mentions": null, "caption length": 120, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 171, "link": "https://www.instagram.com/p/CAdtEEzH20p/", "type": "photo", "likes/views": 90091, "caption": "Need a fire throwback song to add to #miquelacovers, drop your favs in the comments (NOT WONDERWALL)!", "hashtags": "#miquelacovers", "mentions": null, "caption length": 101, "emoji count": 0, "hashtag count": 1.0, "mentions count": null}, {"post number": 172, "link": "https://www.instagram.com/p/CAbBPjrnoq_/", "type": "photo", "likes/views": 81838, "caption": "CATEGORY IS: Leather-daddy-sea-monkey's first time at the rave.", "hashtags": null, "mentions": null, "caption length": 63, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 173, "link": "https://www.instagram.com/p/CAYYMq6HyXE/", "type": "photo", "likes/views": 79166, "caption": "Can't manage more than sweatpants for actual meetings, but your girl is serving LOOKS on Omegle. #miquelacovers COMING SOON", "hashtags": "#miquelacovers", "mentions": null, "caption length": 123, "emoji count": 0, "hashtag count": 1.0, "mentions count": null}, {"post number": 174, "link": "https://www.instagram.com/p/CAVzpZxH9eU/", "type": "photo", "likes/views": 118240, "caption": "Workin\u2019 and thottin', workin\u2019 and thottin'", "hashtags": null, "mentions": null, "caption length": 42, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 175, "link": "https://www.instagram.com/p/CATOI1Fnr-g/", "type": "photo", "likes/views": 196020, "caption": "ShE dIdN't LeAvE yOu On ReAd, YoU lEfT hEr On SpEeChLeSs. I HATE IT HERE.", "hashtags": null, "mentions": null, "caption length": 73, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 176, "link": "https://www.instagram.com/p/CAQ8_Ztn_9s/", "type": "photo", "likes/views": 63105, "caption": "Just so we're clear: THIS is like 85-90% of the creative process. This right here. Tell me if I'm wrong in the comments.", "hashtags": null, "mentions": null, "caption length": 120, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 177, "link": "https://www.instagram.com/p/CAQRq1RHUnP/", "type": "photo", "likes/views": 131749, "caption": "The many faces of WFH. Been getting this #miquelacovers project together and the wifi rarely wants to see me shine.", "hashtags": "#miquelacovers", "mentions": null, "caption length": 115, "emoji count": 0, "hashtag count": 1.0, "mentions count": null}, {"post number": 178, "link": "https://www.instagram.com/p/CAN98VtnwYH/", "type": "photo", "likes/views": 63945, "caption": "Y\u2019all know the homies and I have been working on something creative to help raise money for @musicares in partnership with the @plus1org Covid-19 Relief Fund. There\u2019s more info about this amazing cause in my highlights. Send some help if you can. Stay tuned and stay safe. #MiquelaCovers", "hashtags": "#MiquelaCovers", "mentions": "['@musicares', '@plus']", "caption length": 287, "emoji count": 0, "hashtag count": 1.0, "mentions count": 2.0}, {"post number": 179, "link": "https://www.instagram.com/p/CAL5VreHuzj/", "type": "photo", "likes/views": 55250, "caption": "@justineskye has been an essential QuaranQueen homie these past few weeks. Her new single \u2018No Options\u2019 just dropped and between us: IT\u2019S EVERYTHING.", "hashtags": null, "mentions": "@justineskye", "caption length": 148, "emoji count": 0, "hashtag count": null, "mentions count": 1.0}, {"post number": 180, "link": "https://www.instagram.com/p/CAI8ydBHdLF/", "type": "photo", "likes/views": 69965, "caption": "The face my laptop makes when I'm trying to run @ableton and watch 90DayFianc\u00e9 at the same time. Also, Darcy: I meann. For real I can't with y'all \ud83d\ude02", "hashtags": null, "mentions": "@ableton", "caption length": 148, "emoji count": 1, "hashtag count": null, "mentions count": 1.0}, {"post number": 181, "link": "https://www.instagram.com/p/CAGYVfMHqnR/", "type": "photo", "likes/views": 97282, "caption": "So I drop a #MiquelaCovers in a caption, and the DMs go WILD!?! I mean, definitely keep sending 'em - your girl LOVES TO SEE IT \ud83e\udd16 Y'all are TOO MUCH!", "hashtags": "#MiquelaCovers", "mentions": null, "caption length": 149, "emoji count": 1, "hashtag count": 1.0, "mentions count": null}, {"post number": 182, "link": "https://www.instagram.com/p/CAD_iPen7b8/", "type": "photo", "likes/views": 73966, "caption": "#takemeback but fill the room with all the homies. Also, #miquelacovers coming in HOT.", "hashtags": "['#takemeback', '#miquelacovers']", "mentions": null, "caption length": 86, "emoji count": 0, "hashtag count": 2.0, "mentions count": null}, {"post number": 183, "link": "https://www.instagram.com/p/CABE3inntil/", "type": "photo", "likes/views": 69892, "caption": "So. I\u2019ve been using my stay-inside-energy to focus on music. But on some real stuff: it's been HARD. Turns out studio sessions on Skype aren't really a thing. Also, it's kind of impossible to be productive when your mind is somewhere else. I keep thinking about how hard folks have been impacted - musicians and music industry workers included. Obvious next question: What can I do to help? I hit up a bunch of talented homies, and we decided to collab on something creative; we'll be raising money and hopefully bringing y'all some joy at the same time. More news on that dropping soon, but for now: text 'MIQUELA' to 50155 to donate to @musicares in partnership with the @plus1org Covid-19 Relief Fund. Learn more about this awesome cause in my stories.", "hashtags": null, "mentions": "['@musicares', '@plus']", "caption length": 755, "emoji count": 0, "hashtag count": null, "mentions count": 2.0}, {"post number": 184, "link": "https://www.instagram.com/p/B_-VYGpnDt5/", "type": "photo", "likes/views": 95840, "caption": "THIS WAS 8 WEEKS AGO. I dream about the days when we can go back into liquor stores and buy some unscheduled, non-essential Takis.", "hashtags": null, "mentions": null, "caption length": 130, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 185, "link": "https://www.instagram.com/p/B_7tW5MnrK5/", "type": "video", "likes/views": 734466, "caption": "Always thought I was baby, my new filter #WalletSize has big Diamond energy - tell me what y'all are! I know I've seen some Karens in the comments \ud83e\uddd0", "hashtags": "#WalletSize", "mentions": null, "caption length": 148, "emoji count": 1, "hashtag count": 1.0, "mentions count": null}, {"post number": 186, "link": "https://www.instagram.com/p/B_5jRubnCW5/", "type": "photo", "likes/views": 64620, "caption": "NEW STICKERS. NEW FILTER. Since we can't take mall pics anytime soon, @96step + I decided to bless y'all.", "hashtags": null, "mentions": null, "caption length": 105, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 187, "link": "https://www.instagram.com/p/B_2-XMOH9f1/", "type": "photo", "likes/views": 708474, "caption": "When there's no people here, the Westside is actually kind of chill.", "hashtags": null, "mentions": null, "caption length": 68, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 188, "link": "https://www.instagram.com/p/B_0PgR-nYB2/", "type": "photo", "likes/views": 89717, "caption": "Me when I see the not NOT hot homie at the park from 12 feet away: is this flirting? \ud83e\udd8b", "hashtags": null, "mentions": null, "caption length": 86, "emoji count": 1, "hashtag count": null, "mentions count": null}, {"post number": 189, "link": "https://www.instagram.com/p/B_xsiZPHmW4/", "type": "photo", "likes/views": 106099, "caption": "What if I just stopped doing buns?", "hashtags": null, "mentions": null, "caption length": 34, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 190, "link": "https://www.instagram.com/p/B_vQIUWHvf3/", "type": "photo", "likes/views": 98940, "caption": "If I could go back in time, I would've slept at @sojinails house on Mar. 13th, and just kept my \ud83c\udf51 there until all this was over. RIP these tips \ud83d\udc85", "hashtags": null, "mentions": "@sojinails", "caption length": 145, "emoji count": 2, "hashtag count": null, "mentions count": 1.0}, {"post number": 191, "link": "https://www.instagram.com/p/B_sjyguH4IR/", "type": "photo", "likes/views": 67258, "caption": "NEW RULE: Dressing like you\u2019re on vacation MEANS YOU\u2019RE ON VACATION. Don\u2019t @ me.", "hashtags": null, "mentions": null, "caption length": 80, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 192, "link": "https://www.instagram.com/p/B_p62i7HtuI/", "type": "photo", "likes/views": 71056, "caption": "This time in quarantine has brought me and my family closer than ever #togetherathome (my bougie cousin Roomba refused to pose for this pic. RUDE.)", "hashtags": "#togetherathome", "mentions": null, "caption length": 147, "emoji count": 0, "hashtag count": 1.0, "mentions count": null}, {"post number": 193, "link": "https://www.instagram.com/p/B_nY-KYnjV9/", "type": "photo", "likes/views": 69513, "caption": "I'm LE TIRED. Unwind recommendations in the comments please.", "hashtags": null, "mentions": null, "caption length": 60, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 194, "link": "https://www.instagram.com/p/B_k3w5gHrTt/", "type": "photo", "likes/views": 123763, "caption": "My new song MACHINE likes to be listened to from the back \ud83d\ude18 LINK IN BIO.", "hashtags": null, "mentions": null, "caption length": 72, "emoji count": 1, "hashtag count": null, "mentions count": null}, {"post number": 195, "link": "https://www.instagram.com/p/B_iKjdwn04O/", "type": "photo", "likes/views": 73454, "caption": "ME UPDATE: Machine and Forever BOTH dropped and I got a chain with my face on it. TAURUS SEASON ON 10.", "hashtags": null, "mentions": null, "caption length": 102, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 196, "link": "https://www.instagram.com/p/B_fpIn-nMzW/", "type": "photo", "likes/views": 57952, "caption": "Riverdale, but make the theme song MACHINE (OUT NOW). Clearly I'm Archie, Veronica auditions happening in the comments.", "hashtags": null, "mentions": null, "caption length": 119, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 197, "link": "https://www.instagram.com/p/B_c9unZnF6W/", "type": "photo", "likes/views": 111317, "caption": "2 truths and a lie: I'm real. This chain is real. FOREVER is OUT NOW. (hit the link, duh)", "hashtags": null, "mentions": null, "caption length": 89, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 198, "link": "https://www.instagram.com/p/B_algs4HlwG/", "type": "photo", "likes/views": 57730, "caption": "DM me pics of you dancing to MACHINE. (PLEASE wear pants)", "hashtags": null, "mentions": null, "caption length": 57, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 199, "link": "https://www.instagram.com/p/B_Xn_B6HrBN/", "type": "video", "likes/views": 2460750, "caption": "File under: Songs to make out to when making out is allowed again. Link in bio!", "hashtags": null, "mentions": null, "caption length": 79, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 200, "link": "https://www.instagram.com/p/B_WCsrenMhG/", "type": "photo", "likes/views": 60389, "caption": "Makes an R&B track with @teyanataylor, buys chain. We love to see it.", "hashtags": null, "mentions": "@teyanataylor", "caption length": 69, "emoji count": 0, "hashtag count": null, "mentions count": 1.0}, {"post number": 201, "link": "https://www.instagram.com/p/B_VCvsxnM7H/", "type": "video", "likes/views": 2592604, "caption": "MACHINE OUT NOW. The link is forever in my bio \ud83d\udc95", "hashtags": null, "mentions": null, "caption length": 48, "emoji count": 1, "hashtag count": null, "mentions count": null}, {"post number": 202, "link": "https://www.instagram.com/p/B_T2TiSnIxv/", "type": "photo", "likes/views": 46140, "caption": "Since y'all clearly slept on organizing my quarantine bday parade, I'm expecting you to hit the link and listen to MACHINE, like RIGHT NOW.", "hashtags": null, "mentions": null, "caption length": 139, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 203, "link": "https://www.instagram.com/p/B_SshTzHNU_/", "type": "photo", "likes/views": 52476, "caption": "All I want for my Bday is a million streams. MACHINE ft. @teyanataylor. COMING SOON. LINK IN BIO.", "hashtags": null, "mentions": "@teyanataylor", "caption length": 97, "emoji count": 0, "hashtag count": null, "mentions count": 1.0}, {"post number": 204, "link": "https://www.instagram.com/p/B_RCDYcnQN_/", "type": "video", "likes/views": 728820, "caption": "MACHINE \ud83e\udd16 APRIL 23\n\nThe day I found out TEYANA (yes, as in TAYLOR) was hopping on my new song MACHINE, I was wearing what I now consider my good luck charms (some cute @themjewelers tings). Reached out to some of my fav bbs to tell me about their good luck charms.\n\nSending the biggest virtual hugs to everyone who made this possible \ud83d\udc98\nMACHINE featuring @teyanataylor\nCasting and Directing by @Harperslate\n\nEditing by @babyczeri\n\nFeaturing:\n@wssm6\n@samueldesaboia\n@brindanotbrenda\n@esamanavarrete\n@jbadvss\n@francksinner\n@w3tter\n@v_camps\n@kidaskyblue\n@georginatrevino\n@shabakaaa\n\n#Machine #NewMusic", "hashtags": "['#Machine', '#NewMusic']", "mentions": "['@themjewelers', '@teyanataylor', '@Harperslate', '@babyczeri', '@wssm', '@samueldesaboia', '@brindanotbrenda', '@esamanavarrete', '@jbadvss', '@francksinner', '@w', '@v', '@kidaskyblue', '@georginatrevino', '@shabakaaa']", "caption length": 597, "emoji count": 2, "hashtag count": 2.0, "mentions count": 15.0}, {"post number": 205, "link": "https://www.instagram.com/p/B_Qdc5FnTx5/", "type": "photo", "likes/views": 52694, "caption": "Machine is dropping V SOON. Drop a \ud83c\udf08 in the comments and I'll hit your DMs with a preview.", "hashtags": null, "mentions": null, "caption length": 90, "emoji count": 1, "hashtag count": null, "mentions count": null}, {"post number": 206, "link": "https://www.instagram.com/p/B_NsXfSnRLz/", "type": "video", "likes/views": 877975, "caption": "MACHINE is COMING SOON (I'll remind y'all tomorrow, cause...\ud83e\udd66)", "hashtags": null, "mentions": null, "caption length": 62, "emoji count": 1, "hashtag count": null, "mentions count": null}, {"post number": 207, "link": "https://www.instagram.com/p/B_K-2FhnJME/", "type": "photo", "likes/views": 43711, "caption": "NBD, but last year I put @teyanataylor on my vision board, and now MACHINE IS COMING SOON.", "hashtags": null, "mentions": "@teyanataylor", "caption length": 90, "emoji count": 0, "hashtag count": null, "mentions count": 1.0}, {"post number": 208, "link": "https://www.instagram.com/p/B_IcrLJHx3y/", "type": "photo", "likes/views": 55141, "caption": "Third try recreating this @patmcgrathreal look from the @maisonvalentino show, and tbh I feel like I. DID. THAT, non?", "hashtags": null, "mentions": "['@patmcgrathreal', '@maisonvalentino']", "caption length": 117, "emoji count": 0, "hashtag count": null, "mentions count": 2.0}, {"post number": 209, "link": "https://www.instagram.com/p/B_GNEmlnZRV/", "type": "photo", "likes/views": 43903, "caption": "If YoU DoN't CoMe OuT oF ThIS QuArAnTiNe WiTh a NeW sOnG...", "hashtags": null, "mentions": null, "caption length": 59, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 210, "link": "https://www.instagram.com/p/B_DYiAUJWJE/", "type": "video", "likes/views": 903727, "caption": "\ud83d\udde3 HEY MIQUELA \ud83e\udd16 ft. PABLLO VITTAR\n\nInterviewing the homies on IGTV...first episode of HEY MIQUELA with my queen @PablloVittar.", "hashtags": null, "mentions": "@PablloVittar", "caption length": 126, "emoji count": 2, "hashtag count": null, "mentions count": 1.0}, {"post number": 211, "link": "https://www.instagram.com/p/B_Awpv7HsT-/", "type": "photo", "likes/views": 74484, "caption": "Anyone know a contactless film developer? Still have all these rolls from Paris.", "hashtags": null, "mentions": null, "caption length": 80, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 212, "link": "https://www.instagram.com/p/B--UgMwn6Dw/", "type": "photo", "likes/views": 110171, "caption": "@pabllovittar and I just blessed y'all with the FIRE playlist. Let's pretend it\u2019s Saturday and GO OFF (I meaaan....since all these days be lookin' the damn same anyway)", "hashtags": null, "mentions": "@pabllovittar", "caption length": 168, "emoji count": 0, "hashtag count": null, "mentions count": 1.0}, {"post number": 213, "link": "https://www.instagram.com/p/B-8GhA6nLBN/", "type": "photo", "likes/views": 107289, "caption": "IRL I'm laying on the floor of my living room, but IN MY MIND I'm back in Salvador with @pabllovittar on top of a float, shaking my BUNDA \ud83c\udf51\ud83c\udf51 \ud83c\udf51", "hashtags": null, "mentions": "@pabllovittar", "caption length": 142, "emoji count": 3, "hashtag count": null, "mentions count": 1.0}, {"post number": 214, "link": "https://www.instagram.com/p/B-2Tv_wn8hV/", "type": "photo", "likes/views": 98271, "caption": "Missing my boo @rosalia.vt, not missing all y'all @sigmachi pledges stepping on my kicks in the Sahara Tent.", "hashtags": null, "mentions": "['@rosalia', '@sigmachi']", "caption length": 108, "emoji count": 0, "hashtag count": null, "mentions count": 2.0}, {"post number": 215, "link": "https://www.instagram.com/p/B-0l6Y6HpHu/", "type": "photo", "likes/views": 62923, "caption": "TF YOU MEAN I'M ACTIN' DIFFERENT?", "hashtags": null, "mentions": null, "caption length": 33, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 216, "link": "https://www.instagram.com/p/B-z6n9SnfJI/", "type": "photo", "likes/views": 103427, "caption": "Who got their Vitamin D today?", "hashtags": null, "mentions": null, "caption length": 30, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 217, "link": "https://www.instagram.com/p/B-xaagMnA5f/", "type": "photo", "likes/views": 55058, "caption": "Anybody else as sad as this grass? \ud83e\udd74", "hashtags": null, "mentions": null, "caption length": 36, "emoji count": 1, "hashtag count": null, "mentions count": null}, {"post number": 218, "link": "https://www.instagram.com/p/B-p0o7yHYs0/", "type": "photo", "likes/views": 60599, "caption": "Please click the link in my bio, cause @bermudaisbae is tired of me posting about this damn #SpeakUp remix.", "hashtags": "#SpeakUp", "mentions": "@bermudaisbae", "caption length": 107, "emoji count": 0, "hashtag count": 1.0, "mentions count": 1.0}, {"post number": 219, "link": "https://www.instagram.com/p/B-m9pUmnLc5/", "type": "photo", "likes/views": 50257, "caption": "SPEAK UP REMIX, LINK IN BIO \ud83d\udc7d", "hashtags": null, "mentions": null, "caption length": 29, "emoji count": 1, "hashtag count": null, "mentions count": null}, {"post number": 220, "link": "https://www.instagram.com/p/B-hoGMmnaUv/", "type": "photo", "likes/views": 83549, "caption": "Listening to the new Taska Black remix of #SpeakUp while I organize images on my desktop is all I have planned for the next 3 days. Link in my bio - go Marie Kondo something!", "hashtags": "#SpeakUp", "mentions": null, "caption length": 174, "emoji count": 0, "hashtag count": 1.0, "mentions count": null}, {"post number": 221, "link": "https://www.instagram.com/p/B-dumBmHCuI/", "type": "photo", "likes/views": 29647, "caption": "#SpeakUp was a vibe, but the @taskablack REMIX IS EVEN VIBIER! Link in my bio \ud83d\udc7d", "hashtags": "#SpeakUp", "mentions": "@taskablack", "caption length": 79, "emoji count": 1, "hashtag count": 1.0, "mentions count": 1.0}, {"post number": 222, "link": "https://www.instagram.com/p/B-c57JtnqjA/", "type": "photo", "likes/views": 40782, "caption": "Can we all just agree that APRIL FOOLS 2020 IS CANCELLED? So In celebration of March 32nd, I posted some new ways to \ud83d\udc95Recharge Your Heart\ud83d\udc95 in my stories. I'll keep sharing these every couple days, so if you have any suggestions, drop 'em in the comments! \ud83d\udc95\ud83d\udc95", "hashtags": null, "mentions": null, "caption length": 257, "emoji count": 4, "hashtag count": null, "mentions count": null}, {"post number": 223, "link": "https://www.instagram.com/p/B-aWcN4HZLD/", "type": "video", "likes/views": 1370261, "caption": "I\u2019m Miquela and I make questionable decisions\n\nThrowing it back to shooting a music video with my ex. \ud83d\ude43 #SpeakUp", "hashtags": "#SpeakUp", "mentions": null, "caption length": 112, "emoji count": 1, "hashtag count": 1.0, "mentions count": null}, {"post number": 224, "link": "https://www.instagram.com/p/B-YCguBnU3X/", "type": "photo", "likes/views": 453368, "caption": "Trying to keep that same POSITIVE energy I had at @fivesensecollective on this whateverth day of quarantine we\u2019re on.", "hashtags": null, "mentions": "@fivesensecollective", "caption length": 117, "emoji count": 0, "hashtag count": null, "mentions count": 1.0}, {"post number": 225, "link": "https://www.instagram.com/p/B-QP6kwHY9D/", "type": "photo", "likes/views": 64777, "caption": "Dudes love to say they\u2019re there for you when everything is perfect, but when things go left? Crickets. @nickillian isn\u2019t dudes tho...he\u2019s THE DUDE. He\u2019s been there, down to lend a hand or an ear or a heart or some abs in a music video about your breakup and I\u2019ve been humbled by his kindness. I was kind of scared when we \u2018uncoupled\u2019 because I knew I wasn\u2019t just losing a boyfriend - I was potentially losing my favorite homie. That\u2019s what really TERRIFIED me. It turns out if you let the right person in, there\u2019s nothing to be afraid of - they\u2019ll show up when you need them, and if you\u2019re lucky, they\u2019ll show out. @nickillian has done both. I had a feeling we\u2019d be connected for life, and now more than ever, I know it\u2019s really true.", "hashtags": null, "mentions": "['@nickillian', '@nickillian']", "caption length": 734, "emoji count": 0, "hashtag count": null, "mentions count": 2.0}, {"post number": 226, "link": "https://www.instagram.com/p/B-NWSQbHJv6/", "type": "photo", "likes/views": 60178, "caption": "When we were shooting the #SpeakUp music video and I\u2019d start to freak out, @isabellapapile would calm me down with fire vintage and I\u2019ll love her for that forever.", "hashtags": "#SpeakUp", "mentions": "@isabellapapile", "caption length": 163, "emoji count": 0, "hashtag count": 1.0, "mentions count": 1.0}, {"post number": 227, "link": "https://www.instagram.com/p/B-KrIPqnpox/", "type": "video", "likes/views": 1238342, "caption": "Y\u2019ALL: #SPEAKUP MUSIC VIDEO IS OUT. Link is in my bio, my heart is in ur hands \ud83d\udc95\ud83d\udc95\ud83d\udc95", "hashtags": "#SPEAKUP", "mentions": null, "caption length": 82, "emoji count": 3, "hashtag count": 1.0, "mentions count": null}, {"post number": 228, "link": "https://www.instagram.com/p/B-H0GBWH7ZO/", "type": "video", "likes/views": 1333969, "caption": "CAN\u2019T. BELIEVE. THE. VIDEO. IS. FINALLY. OUT. Opening your heart can be magic. I love y\u2019all so much \ud83d\udc95\ud83d\udc95 #SpeakUp", "hashtags": "#SpeakUp", "mentions": null, "caption length": 111, "emoji count": 2, "hashtag count": 1.0, "mentions count": null}, {"post number": 229, "link": "https://www.instagram.com/p/B-GMN9sneOm/", "type": "video", "likes/views": 1836592, "caption": "The link to watch the #SpeakUp music video is in my bio, tears are in my eyes, and my whole crew is in the chat. Come hang! Where else do you have to be?", "hashtags": "#SpeakUp", "mentions": null, "caption length": 153, "emoji count": 0, "hashtag count": 1.0, "mentions count": null}, {"post number": 230, "link": "https://www.instagram.com/p/B-FkQWkH_Xl/", "type": "photo", "likes/views": 54126, "caption": "REMINDER: watch the #SpeakUp video premiere with me tomorrow! (It\u2019s legit the only thing on my calendar right now, COME TALK TO ME)", "hashtags": "#SpeakUp", "mentions": null, "caption length": 131, "emoji count": 0, "hashtag count": 1.0, "mentions count": null}, {"post number": 231, "link": "https://www.instagram.com/p/B-C2vGPHHpi/", "type": "video", "likes/views": 1564395, "caption": "Y\u2019all: LINK IN BIO! #SpeakUp premiere is 3.24! CAN\u2019T WAIT TO WATCH TOGETHER! (**when I say \u201ctogether\u201d I obviously mean we\u2019ll all be at our own houses, but I\u2019ll be in the chat during the premiere!!) That\u2019s how we doin\u2019 \u201ctogether\u201d right now \ud83d\udc95", "hashtags": "#SpeakUp", "mentions": null, "caption length": 240, "emoji count": 1, "hashtag count": 1.0, "mentions count": null}, {"post number": 232, "link": "https://www.instagram.com/p/B-AfOaMHv33/", "type": "video", "likes/views": 1242420, "caption": "#SpeakUp music video is out 3.24 and I can\u2019t wait for everyone with an internet connection to watch me roll around in my underwear with my real life ex turned BFF/brother and all his abdominal muscles while we reenact our failed relationship in a video that will live on YouTube FOR. EVER. No, for real!! This is gonna be so GREAT!! LOVE THAT FOR ME!! \ud83d\ude43\ud83d\ude43\ud83d\ude43", "hashtags": "#SpeakUp", "mentions": null, "caption length": 355, "emoji count": 3, "hashtag count": 1.0, "mentions count": null}, {"post number": 233, "link": "https://www.instagram.com/p/B9-LunWnc7a/", "type": "photo", "likes/views": 57543, "caption": "I wore this vintage @versace 2 piece and @acnestudios puffer situation in my new music video. I also wore it to pick up a curbside @postmates delivery this morning. There\u2019s levels to this ish. Your girl is versatile. #SpeakUp video drops 3.24, and the looks are poppin.", "hashtags": "#SpeakUp", "mentions": "['@versace', '@acnestudios', '@postmates']", "caption length": 269, "emoji count": 0, "hashtag count": 1.0, "mentions count": 3.0}, {"post number": 234, "link": "https://www.instagram.com/p/B97eMa9ny6B/", "type": "photo", "likes/views": 70460, "caption": "It\u2019s WILD how much can change in 2 weeks...this feels like private-browser level intimacy...ANYONE ELSE JUST WANNA BE HELD?? #SpeakUp video drops 3.24", "hashtags": "#SpeakUp", "mentions": null, "caption length": 150, "emoji count": 0, "hashtag count": 1.0, "mentions count": null}, {"post number": 235, "link": "https://www.instagram.com/p/B94u-ACHP-I/", "type": "video", "likes/views": 1992155, "caption": "Had some semi-awkward feels while shooting the video for Speak Up, but a week and some days later I\u2019m realizing how blessed I was just to be outside, actually touching people I care about. Anyway, the video is out 3/24 and it\u2019s V CUTE", "hashtags": null, "mentions": null, "caption length": 234, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 236, "link": "https://www.instagram.com/p/B92KmvcnBV2/", "type": "photo", "likes/views": 88047, "caption": "I\u2019m bored wyd?", "hashtags": null, "mentions": null, "caption length": 14, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 237, "link": "https://www.instagram.com/p/B9xDR9vnKwG/", "type": "photo", "likes/views": 138820, "caption": "Going to buy gift certificates from some of our favorite small businesses affected by Covid-19. Trying to stay positive for everyone out there. \u2764\ufe0f", "hashtags": null, "mentions": null, "caption length": 146, "emoji count": 1, "hashtag count": null, "mentions count": null}, {"post number": 238, "link": "https://www.instagram.com/p/B9ujEbEnfw1/", "type": "photo", "likes/views": 87621, "caption": "2 MILLION WHOLE ENTIRE FOLLOWERS \ud83c\udf89 \ud83c\udf89 \ud83c\udf89 Thank you SO much for tuning in. Wash ur hands, don\u2019t be xenophobic and enjoy this photo of when I met my very first cat in Brazil. Swipe for a surprise \ud83d\udc31", "hashtags": null, "mentions": null, "caption length": 193, "emoji count": 4, "hashtag count": null, "mentions count": null}, {"post number": 239, "link": "https://www.instagram.com/p/B9ry_s2nKsM/", "type": "photo", "likes/views": 70231, "caption": "Speak Up is out. I\u2019m off for a sound bath recharge. Love y\u2019all \u270c\ufe0f", "hashtags": null, "mentions": null, "caption length": 65, "emoji count": 1, "hashtag count": null, "mentions count": null}, {"post number": 240, "link": "https://www.instagram.com/p/B9pmJBTnlqw/", "type": "video", "likes/views": 2150225, "caption": "\ud83d\udd08SOUND ON \ud83d\udd08 I love me \ud83d\ude43", "hashtags": null, "mentions": null, "caption length": 23, "emoji count": 3, "hashtag count": null, "mentions count": null}, {"post number": 241, "link": "https://www.instagram.com/p/B9o4v_FHzW3/", "type": "photo", "likes/views": 56159, "caption": "The you know what about you know who is OUT NOW. Link in bio. Stomach in throat. #SpeakUp", "hashtags": "#SpeakUp", "mentions": null, "caption length": 89, "emoji count": 0, "hashtag count": 1.0, "mentions count": null}, {"post number": 242, "link": "https://www.instagram.com/p/B9nrz3OHjmp/", "type": "video", "likes/views": 3353236, "caption": "I mean I rly made it for me, but I don\u2019t mind if y\u2019all listen \ud83d\ude18 #SpeakUp", "hashtags": "#SpeakUp", "mentions": null, "caption length": 72, "emoji count": 1, "hashtag count": 1.0, "mentions count": null}, {"post number": 243, "link": "https://www.instagram.com/p/B9mpF3Pn_WX/", "type": "photo", "likes/views": 83305, "caption": "Add #SpeakUp to your quarantine playlist \ud83d\udc7d", "hashtags": "#SpeakUp", "mentions": null, "caption length": 42, "emoji count": 1, "hashtag count": 1.0, "mentions count": null}, {"post number": 244, "link": "https://www.instagram.com/p/B9j-XgZHsS7/", "type": "photo", "likes/views": 60556, "caption": "This pic of me wearing mascara is supposed to signify that I'm doing way better, focusing on myself, writing music and not at all thinking about my ex or whatever. Drop a \ud83d\udc7d in the comments if I did this right. #speakup 3.12", "hashtags": "#speakup", "mentions": null, "caption length": 223, "emoji count": 1, "hashtag count": 1.0, "mentions count": null}, {"post number": 245, "link": "https://www.instagram.com/p/B9hpoJ_noAc/", "type": "photo", "likes/views": 72411, "caption": "Went through a breakup, wrote a song about it. Wait - did I just invent a thing? Idk, but it feels like I did. #SpeakUp", "hashtags": "#SpeakUp", "mentions": null, "caption length": 119, "emoji count": 0, "hashtag count": 1.0, "mentions count": null}, {"post number": 246, "link": "https://www.instagram.com/p/B9estyun6U1/", "type": "video", "likes/views": 1319915, "caption": "Y\u2019all know how I am...I couldn\u2019t help myself \ud83d\ude43 Link in bio.", "hashtags": null, "mentions": null, "caption length": 59, "emoji count": 1, "hashtag count": null, "mentions count": null}, {"post number": 247, "link": "https://www.instagram.com/p/B9cNh70HQLH/", "type": "video", "likes/views": 2826650, "caption": "Big things coming soon!", "hashtags": null, "mentions": null, "caption length": 23, "emoji count": 0, "hashtag count": null, "mentions count": null}, {"post number": 248, "link": "https://www.instagram.com/p/B9ZzyfGna6a/", "type": "photo", "likes/views": 41180, "caption": "New tunes coming soon. Zoom in on my @samsungmobile Galaxy Z Flip for the deets (there's a lil teaser in there for my #TeamGalaxy fam). Been walking around LA all day listening to the final mix and I\u2019m finally ready to share it with you \ud83d\udd1c\ud83c\udfb5\ud83d\ude2d#ad", "hashtags": "['#TeamGalaxy', '#ad']", "mentions": "@samsungmobile", "caption length": 243, "emoji count": 3, "hashtag count": 2.0, "mentions count": 1.0}, {"post number": 249, "link": "https://www.instagram.com/p/B9XstBrHqrj/", "type": "photo", "likes/views": 86739, "caption": "\u26a0\ufe0f Long caption Alert \u26a0\ufe0f\nSo this is the inevitable \u2018Conscious Uncoupling\u2019 post. Basically Nick and I are no longer together (but we love him the most, and if you come for him you can catch these hands. For real. I\u2019m fragile right now, but fully down to fight). That said, the hard part about living your life online is that when stuff goes left (as it always does), you have to explain it\u2026so here goes nothing\u2026Basically, falling in love for the first time is FUCKING INTENSE. I know, I know - I probably should have known that, but your girl is new to all this emotional shit, and it turns out I\u2019ve still got a lot to learn. I thought it would be all rainbows and lollipops and sharing sweatshirts or whatever, but it turns out that there\u2019s way more to it than that. Wild, right? I wasn\u2019t ready for how much I\u2019d end up NEEDING Nick, how alone I\u2019d end up feeling when we were apart, and how much of myself I\u2019d lose while trying to be \u2018perfect\u2019. I\u2019m super grateful that my first experience with love was with someone who cared about me with his whole heart, and even through the embarrassing breakdown and breakup that followed, this legit feels like a breakthrough? I\u2019ve got a lot to do, a lot to see, a lot of myself to discover, and I know that I probably need to do that alone, you feel me? For everyone wondering - Nick and I will continue to co-parent Bobby Hill and Rosalia (our two ferns) and hope to provide them the love and care they need to continue to flourish. I love you all", "hashtags": null, "mentions": null, "caption length": 1487, "emoji count": 2, "hashtag count": null, "mentions count": null}]}}, {"mode": "vega-lite"});
</script>




```python

Image(filename='Skærmbillede 2020-12-07 kl. 14.08.06.png')
```




![png](output_42_0.png)



### Descriptiv statistik på længden af captions


```python
df['caption length'].isnull().any() #finder ud af om der er NaN værdier
```




    False




```python
round(df['caption length'].describe(),0) # Viser basal deskriptiv statistik
```




    count     250.0
    mean      111.0
    std       126.0
    min         5.0
    25%        59.0
    50%        86.0
    75%       133.0
    max      1487.0
    Name: caption length, dtype: float64




```python
df['caption length'].mean()
```




    110.96




```python
round(df['caption length'].mean(),0) # Gennemsnittet afrundet
```




    111.0




```python
df['caption length'].mode() #Beregner typetallet i antal likes
```




    0    60
    dtype: int64




```python
df['caption length'].plot(kind='box',vert=False, figsize=(10,3))
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7fd17c2f6410>




![png](output_49_1.png)


#### Hvad betyder det at boxplottet over caption length ser sådan ud?
Mængden af tegn i @lilmiquelas captions spreder sig fra  5 - 1487 likes. Der er dog flest af hendes captons som består af under 100 tegn som fordeler sig blandt gennemsnittet. Det er derfor figuren ser mærkelig ud

## Textmining


```python
# Opstiller en samlet liste bestående af alle captions
alle=list()
for i in df.caption:
    alle.append(i)
    str(alle)
alle[:20]
```




    ["This is the first step of MANY. KEEP THAT SAME ENERGY Y'ALL - still so much to do.",
     "Wearing all Praying cause that's what all I been doin 😇",
     "Fav distraction: Looking at apartments I can't afford. Seriously: TRY IT!",
     'I know patience is a virtue, but DAMN!! Are we planning a party or an escape, your girl NEEDS TO KNOW!',
     'Anxiety meter already broke 🤖 Recharging with cuddles and sheet masks 🐶🤡 PLEASE SEND TACO.',
     "Y'ALL KNOW WHAT TIME IT IS. Get out there!",
     "Running out of ways to remind y'all, but you can't spell VOTE without the V.",
     'Supermodel felt too basic for Halloween, but the fit was FIRE. So, here we are.',
     'Dressed as fierce queens this whole week, but saved the FIERCEST queen for last: #91, Mr. Rodman, I LOVE YOU.',
     "Leeloo Dallas is cute, but it's Ruby Rhod for me.",
     'To my fans …. I want to thank you guys so much for your support throughout the years !!!!! PS first pic is the original 💋 !!!!',
     'Throwback to last year when I dressed up as another ageless beauty. #19forever',
     '@pabllovittar sis, did I snap?',
     "Had to give ya'll the full look. We keep it strictly prickly.",
     'Had lunch with a human emoji. Find a cuter 🦁. I dare u.',
     'When you think you\'re a cute mermaid, but someone yells "GO \'HEAD THICC COVID-19" while you wait in line for boba 🥴🥴',
     "If y'all call me Regina George one more time...",
     "Drop your low effort Halloween costumes in the comments (I'm not going anywhere, and honestly neither should y'all)",
     'Bringing back yoga pants. Fight Me.',
     'MayMay told me the story behind "Ring Around the Rosie"... SO. DARK.']




```python
# Opstiller en ny liste bestående af alle ord fra caption
tot=[]
for i in df.caption:
    tot.extend(i.split())
tot[:20]
```




    ['This',
     'is',
     'the',
     'first',
     'step',
     'of',
     'MANY.',
     'KEEP',
     'THAT',
     'SAME',
     'ENERGY',
     "Y'ALL",
     '-',
     'still',
     'so',
     'much',
     'to',
     'do.',
     'Wearing',
     'all']




```python
len(tot) #Antallet af ord
```




    5083




```python
#Laver ovenstående liste om til et 'set', der automatisk fjerne alle redunante ord
unique=set(tot)
#unique
```


```python
# optæller antaller af unikke ord
uni_count=0
for i in unique:
    uni_count=uni_count+1
    
print('Antallet af unikke ord er:',uni_count)
```

    Antallet af unikke ord er: 2243



```python
# Biblioteket Counter bruges til at optælle hyppigheden for hvert ord
counter=Counter(tot)
counter.most_common(20)
```




    [('the', 138),
     ('to', 122),
     ('and', 109),
     ('I', 107),
     ('my', 100),
     ('a', 95),
     ('in', 89),
     ('is', 75),
     ('for', 61),
     ('of', 48),
     ('on', 45),
     ('this', 40),
     ('but', 39),
     ('you', 39),
     ('me', 32),
     ('with', 31),
     ('like', 27),
     ('your', 25),
     ('it', 25),
     ('out', 24)]




```python
# Downloader de engelske 'stopwords', der bruges til at fjerne de mest almindelige ord
nltk.download('stopwords')
```

    [nltk_data] Downloading package stopwords to /home/jovyan/nltk_data...
    [nltk_data]   Package stopwords is already up-to-date!





    True




```python
stop_words = set(stopwords.words('english'))

def remove_stopwords(tot): #fjerner stopwords fra listen af ord
    return [t for t in tot if t not in stop_words]

# genoptæller ordene
counter = Counter(remove_stopwords(tot))
print(counter.most_common(20)) #print de mest hyppigt brugte ord
```

    [('I', 107), ('like', 27), ("I'm", 22), ("y'all", 20), ('video', 18), ('know', 16), ('#SpeakUp', 16), ('love', 15), ('The', 15), ('IN', 15), ('Link', 14), ('LINK', 13), ('-', 12), ('#miquelacovers', 12), ('link', 11), ('This', 10), ('girl', 10), ('new', 10), ('HARD', 10), ('first', 9)]



```python
# Opstiller en  dataframe med ord og deres optællinger
freq_df = pd.DataFrame.from_records(counter.most_common(20),
                                   columns=['words', 'count'])

freq_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>words</th>
      <th>count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>I</td>
      <td>107</td>
    </tr>
    <tr>
      <th>1</th>
      <td>like</td>
      <td>27</td>
    </tr>
    <tr>
      <th>2</th>
      <td>I'm</td>
      <td>22</td>
    </tr>
    <tr>
      <th>3</th>
      <td>y'all</td>
      <td>20</td>
    </tr>
    <tr>
      <th>4</th>
      <td>video</td>
      <td>18</td>
    </tr>
    <tr>
      <th>5</th>
      <td>know</td>
      <td>16</td>
    </tr>
    <tr>
      <th>6</th>
      <td>#SpeakUp</td>
      <td>16</td>
    </tr>
    <tr>
      <th>7</th>
      <td>love</td>
      <td>15</td>
    </tr>
    <tr>
      <th>8</th>
      <td>The</td>
      <td>15</td>
    </tr>
    <tr>
      <th>9</th>
      <td>IN</td>
      <td>15</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Link</td>
      <td>14</td>
    </tr>
    <tr>
      <th>11</th>
      <td>LINK</td>
      <td>13</td>
    </tr>
    <tr>
      <th>12</th>
      <td>-</td>
      <td>12</td>
    </tr>
    <tr>
      <th>13</th>
      <td>#miquelacovers</td>
      <td>12</td>
    </tr>
    <tr>
      <th>14</th>
      <td>link</td>
      <td>11</td>
    </tr>
    <tr>
      <th>15</th>
      <td>This</td>
      <td>10</td>
    </tr>
    <tr>
      <th>16</th>
      <td>girl</td>
      <td>10</td>
    </tr>
    <tr>
      <th>17</th>
      <td>new</td>
      <td>10</td>
    </tr>
    <tr>
      <th>18</th>
      <td>HARD</td>
      <td>10</td>
    </tr>
    <tr>
      <th>19</th>
      <td>first</td>
      <td>9</td>
    </tr>
  </tbody>
</table>
</div>




```python
#beregner procenten for ordenes hyppighed ud fra de 20 mest fremkomne ord
freq_df['%']=round(freq_df['count']/freq_df['count'].sum()*100)
```


```python
freq_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>words</th>
      <th>count</th>
      <th>%</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>I</td>
      <td>107</td>
      <td>28.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>like</td>
      <td>27</td>
      <td>7.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>I'm</td>
      <td>22</td>
      <td>6.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>y'all</td>
      <td>20</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>video</td>
      <td>18</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>know</td>
      <td>16</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>#SpeakUp</td>
      <td>16</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>love</td>
      <td>15</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>The</td>
      <td>15</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>IN</td>
      <td>15</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Link</td>
      <td>14</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>11</th>
      <td>LINK</td>
      <td>13</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>12</th>
      <td>-</td>
      <td>12</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>13</th>
      <td>#miquelacovers</td>
      <td>12</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>14</th>
      <td>link</td>
      <td>11</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>15</th>
      <td>This</td>
      <td>10</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>16</th>
      <td>girl</td>
      <td>10</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>17</th>
      <td>new</td>
      <td>10</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>18</th>
      <td>HARD</td>
      <td>10</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>19</th>
      <td>first</td>
      <td>9</td>
      <td>2.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Visualisering af ordnes hyppighed
freq_df.plot.bar(x ='words', color='seashell', edgecolor='pink', figsize=(10,6))
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7fd17c391990>




![png](output_63_1.png)



```python
def wordcloud(counter): #opstiller en funktion der generere et wordcloud ud fra ordned hyppighed
    wc = WordCloud(width=1200, height=800,
                  max_words=100,
                  background_color="white")
    wc.generate_from_frequencies(counter)
    
    #Plot
    fig=plt.figure(figsize=(10,6))
    plt.imshow(wc, interpolation='bilinear')
    plt.axis("off")
    plt.tight_layout(pad=0)
    plt.show()
```


```python
#Create wordcloud
wordcloud(counter)
```


![png](output_65_0.png)


#### Nu undersøges brugen af emojis:


```python
def extract_emojis(s): #Opstiller en liste udelukkende bestående af de benyttede emojis
    return ''.join(c for c in s if c in emoji.UNICODE_EMOJI)
emo=list(extract_emojis(str(alle)))
```


```python
emo[:20]
```




    ['😇',
     '🤖',
     '🐶',
     '🤡',
     '💋',
     '🦁',
     '🥴',
     '🥴',
     '🖤',
     '🐄',
     '🦓',
     '🖤',
     '👁',
     '💔',
     '🤡',
     '🍔',
     '😈',
     '🍝',
     '❤',
     '🍝']




```python
freq_df1 = pd.DataFrame.from_records(Counter(emo).most_common(20), #Benytter biblioteket Counter til at beregne emojisne hyppighed
                                   columns=['emoji', 'count'])
freq_df1['%']=round(freq_df1['count']/freq_df1['count'].sum()*100)
freq_df1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>emoji</th>
      <th>count</th>
      <th>%</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>💕</td>
      <td>16</td>
      <td>17.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>🙃</td>
      <td>7</td>
      <td>7.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>😭</td>
      <td>7</td>
      <td>7.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>🤖</td>
      <td>6</td>
      <td>6.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>💞</td>
      <td>5</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>😘</td>
      <td>5</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>🥺</td>
      <td>5</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>🍑</td>
      <td>5</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>👽</td>
      <td>5</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>❤</td>
      <td>4</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>10</th>
      <td>🎀</td>
      <td>4</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>11</th>
      <td>✨</td>
      <td>4</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>12</th>
      <td>✅</td>
      <td>4</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>13</th>
      <td>🥴</td>
      <td>3</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>14</th>
      <td>😊</td>
      <td>3</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>15</th>
      <td>🥰</td>
      <td>3</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>16</th>
      <td>🎉</td>
      <td>3</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>17</th>
      <td>🤡</td>
      <td>2</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>18</th>
      <td>💋</td>
      <td>2</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>19</th>
      <td>🖤</td>
      <td>2</td>
      <td>2.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Visualisere hyppigheden for emojis
freq_df1['count'].plot.bar(color=['lightgreen'], edgecolor='blue')
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7fd17c382290>




![png](output_70_1.png)


#### Nu undersøges brugen af hashtags:


```python
df['hashtags'].isnull().any() #finder ud af om der er NaN værdier
```




    True




```python
#Fjerner NaN's fra listen
cleanedList = [x for x in df['hashtags'] if str(x) != 'nan' and '[' and ']']
cleanedList
```




    ['#nationalpastaday',
     "['#returnyourballotday', '#makeyourvotecount']",
     '#Lakers',
     '#GCFAItalia',
     '#comicon',
     '#Girlfriends',
     "['#reading', '#comments']",
     '#botgirlsummer',
     '#answeringquestions',
     "['#NationalVoterRegistrationDay', '#MOBBTheVote', '#MarchOnBallotBoxes']",
     '#bigthingscomingsoon',
     '#climatechange',
     '#gamergirl',
     '#bershkastyle',
     "['#anime', '#animeedits']",
     '#HardFeelingsRemix',
     '#HardFeelings',
     '#HardFeelingsRemix',
     '#HardFeelingsRemix',
     '#HardFeelingsRemix',
     '#freebritney',
     '#HardFeelings',
     '#theLastDance',
     '#HardFeelings',
     '#HardFeelings',
     '#HardFeelings',
     '#miquela',
     '#hardfeelings',
     '#miquelacovers',
     '#miquelacovers',
     '#miquelacovers',
     '#miquelacovers',
     '#miquelacovers',
     '#miquelacovers',
     '#buyblack',
     '#miquelacovers',
     '#miquelacovers',
     '#miquelacovers',
     '#miquelacovers',
     '#miquelacovers',
     '#miquelacovers',
     '#MiquelaCovers',
     '#MiquelaCovers',
     "['#takemeback', '#miquelacovers']",
     '#WalletSize',
     '#togetherathome',
     "['#Machine', '#NewMusic']",
     '#SpeakUp',
     '#SpeakUp',
     '#SpeakUp',
     '#SpeakUp',
     '#SpeakUp',
     '#SPEAKUP',
     '#SpeakUp',
     '#SpeakUp',
     '#SpeakUp',
     '#SpeakUp',
     '#SpeakUp',
     '#SpeakUp',
     '#SpeakUp',
     '#SpeakUp',
     '#SpeakUp',
     '#SpeakUp',
     '#speakup',
     '#SpeakUp',
     "['#TeamGalaxy', '#ad']"]




```python
str(df['hashtags'])
```




    "0                         NaN\n1                         NaN\n2                         NaN\n3                         NaN\n4                         NaN\n                ...          \n245                  #SpeakUp\n246                       NaN\n247                       NaN\n248    ['#TeamGalaxy', '#ad']\n249                       NaN\nName: hashtags, Length: 250, dtype: object"




```python
tags=[]
for i in str(df['hashtags']):
    tags.extend(i.split())
tags[:20]
```




    ['0',
     'N',
     'a',
     'N',
     '1',
     'N',
     'a',
     'N',
     '2',
     'N',
     'a',
     'N',
     '3',
     'N',
     'a',
     'N',
     '4',
     'N',
     'a',
     'N']




```python
tot=[]
for i in df.caption:
    tot.extend(i.split())
tot[:20]
```




    ['This',
     'is',
     'the',
     'first',
     'step',
     'of',
     'MANY.',
     'KEEP',
     'THAT',
     'SAME',
     'ENERGY',
     "Y'ALL",
     '-',
     'still',
     'so',
     'much',
     'to',
     'do.',
     'Wearing',
     'all']




```python

```

# Machine Learning


```python
df.type=pd.Categorical(df.type)
df['type']=df['type'].cat.codes #ændrer Type til at være en kategorisk kodet værdi
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 250 entries, 0 to 249
    Data columns (total 11 columns):
    post number       250 non-null int64
    link              250 non-null object
    type              250 non-null int8
    likes/views       250 non-null int64
    caption           250 non-null object
    hashtags          66 non-null object
    mentions          53 non-null object
    caption length    250 non-null int64
    emoji count       250 non-null int64
    hashtag count     66 non-null float64
    mentions count    53 non-null float64
    dtypes: float64(2), int64(4), int8(1), object(4)
    memory usage: 19.9+ KB



```python
# y dækker over den værdi som vi ønsker at forudsige 
y=df['likes/views'].copy()
y
```




    0        43282
    1        34263
    2        44715
    3        41334
    4        53704
            ...   
    245      72411
    246    1319915
    247    2826650
    248      41180
    249      86739
    Name: likes/views, Length: 250, dtype: int64




```python
X=df[['type', 'caption length']].copy()
X # X dækker over de værdier som vores udforudsigelse bygger på
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>type</th>
      <th>caption length</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>82</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>55</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>73</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>102</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>90</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>245</th>
      <td>0</td>
      <td>119</td>
    </tr>
    <tr>
      <th>246</th>
      <td>1</td>
      <td>59</td>
    </tr>
    <tr>
      <th>247</th>
      <td>1</td>
      <td>23</td>
    </tr>
    <tr>
      <th>248</th>
      <td>0</td>
      <td>243</td>
    </tr>
    <tr>
      <th>249</th>
      <td>0</td>
      <td>1487</td>
    </tr>
  </tbody>
</table>
<p>250 rows × 2 columns</p>
</div>




```python
train_X, test_X, train_y, test_y = train_test_split(X, y, train_size=.8, random_state = 123) 
#train og test-sættet splittes op således at train fylder 80% og test fylder 20%
```


```python
train_X
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>type</th>
      <th>caption length</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>130</th>
      <td>0</td>
      <td>71</td>
    </tr>
    <tr>
      <th>238</th>
      <td>0</td>
      <td>193</td>
    </tr>
    <tr>
      <th>145</th>
      <td>1</td>
      <td>87</td>
    </tr>
    <tr>
      <th>136</th>
      <td>0</td>
      <td>238</td>
    </tr>
    <tr>
      <th>23</th>
      <td>0</td>
      <td>11</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>98</th>
      <td>0</td>
      <td>118</td>
    </tr>
    <tr>
      <th>220</th>
      <td>0</td>
      <td>174</td>
    </tr>
    <tr>
      <th>66</th>
      <td>0</td>
      <td>68</td>
    </tr>
    <tr>
      <th>126</th>
      <td>0</td>
      <td>538</td>
    </tr>
    <tr>
      <th>109</th>
      <td>1</td>
      <td>155</td>
    </tr>
  </tbody>
</table>
<p>200 rows × 2 columns</p>
</div>




```python
test_X
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>type</th>
      <th>caption length</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>127</th>
      <td>0</td>
      <td>143</td>
    </tr>
    <tr>
      <th>187</th>
      <td>0</td>
      <td>68</td>
    </tr>
    <tr>
      <th>24</th>
      <td>0</td>
      <td>34</td>
    </tr>
    <tr>
      <th>206</th>
      <td>1</td>
      <td>62</td>
    </tr>
    <tr>
      <th>235</th>
      <td>1</td>
      <td>234</td>
    </tr>
    <tr>
      <th>31</th>
      <td>0</td>
      <td>111</td>
    </tr>
    <tr>
      <th>20</th>
      <td>0</td>
      <td>9</td>
    </tr>
    <tr>
      <th>202</th>
      <td>0</td>
      <td>139</td>
    </tr>
    <tr>
      <th>196</th>
      <td>0</td>
      <td>119</td>
    </tr>
    <tr>
      <th>201</th>
      <td>1</td>
      <td>48</td>
    </tr>
    <tr>
      <th>85</th>
      <td>0</td>
      <td>66</td>
    </tr>
    <tr>
      <th>82</th>
      <td>0</td>
      <td>69</td>
    </tr>
    <tr>
      <th>19</th>
      <td>0</td>
      <td>68</td>
    </tr>
    <tr>
      <th>163</th>
      <td>0</td>
      <td>19</td>
    </tr>
    <tr>
      <th>198</th>
      <td>0</td>
      <td>57</td>
    </tr>
    <tr>
      <th>122</th>
      <td>0</td>
      <td>184</td>
    </tr>
    <tr>
      <th>234</th>
      <td>0</td>
      <td>150</td>
    </tr>
    <tr>
      <th>95</th>
      <td>1</td>
      <td>36</td>
    </tr>
    <tr>
      <th>231</th>
      <td>1</td>
      <td>240</td>
    </tr>
    <tr>
      <th>156</th>
      <td>0</td>
      <td>149</td>
    </tr>
    <tr>
      <th>53</th>
      <td>0</td>
      <td>134</td>
    </tr>
    <tr>
      <th>61</th>
      <td>0</td>
      <td>18</td>
    </tr>
    <tr>
      <th>188</th>
      <td>0</td>
      <td>86</td>
    </tr>
    <tr>
      <th>157</th>
      <td>0</td>
      <td>94</td>
    </tr>
    <tr>
      <th>215</th>
      <td>0</td>
      <td>33</td>
    </tr>
    <tr>
      <th>144</th>
      <td>0</td>
      <td>72</td>
    </tr>
    <tr>
      <th>52</th>
      <td>0</td>
      <td>65</td>
    </tr>
    <tr>
      <th>219</th>
      <td>0</td>
      <td>29</td>
    </tr>
    <tr>
      <th>120</th>
      <td>0</td>
      <td>52</td>
    </tr>
    <tr>
      <th>137</th>
      <td>0</td>
      <td>149</td>
    </tr>
    <tr>
      <th>89</th>
      <td>0</td>
      <td>62</td>
    </tr>
    <tr>
      <th>173</th>
      <td>0</td>
      <td>123</td>
    </tr>
    <tr>
      <th>191</th>
      <td>0</td>
      <td>80</td>
    </tr>
    <tr>
      <th>90</th>
      <td>0</td>
      <td>145</td>
    </tr>
    <tr>
      <th>186</th>
      <td>0</td>
      <td>105</td>
    </tr>
    <tr>
      <th>218</th>
      <td>0</td>
      <td>107</td>
    </tr>
    <tr>
      <th>81</th>
      <td>1</td>
      <td>53</td>
    </tr>
    <tr>
      <th>42</th>
      <td>0</td>
      <td>130</td>
    </tr>
    <tr>
      <th>33</th>
      <td>0</td>
      <td>64</td>
    </tr>
    <tr>
      <th>37</th>
      <td>0</td>
      <td>82</td>
    </tr>
    <tr>
      <th>232</th>
      <td>1</td>
      <td>355</td>
    </tr>
    <tr>
      <th>150</th>
      <td>0</td>
      <td>104</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0</td>
      <td>42</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>90</td>
    </tr>
    <tr>
      <th>177</th>
      <td>0</td>
      <td>115</td>
    </tr>
    <tr>
      <th>228</th>
      <td>1</td>
      <td>111</td>
    </tr>
    <tr>
      <th>205</th>
      <td>0</td>
      <td>90</td>
    </tr>
    <tr>
      <th>21</th>
      <td>0</td>
      <td>60</td>
    </tr>
    <tr>
      <th>148</th>
      <td>0</td>
      <td>134</td>
    </tr>
    <tr>
      <th>147</th>
      <td>0</td>
      <td>89</td>
    </tr>
  </tbody>
</table>
</div>




```python
clf = LinearRegression(normalize=True) #Linære regression benyttes
```


```python
clf.fit(train_X,train_y) #modellen trænes
```




    LinearRegression(copy_X=True, fit_intercept=True, n_jobs=None, normalize=True)




```python
y_pred=clf.predict(test_X)
y_pred #Vores forudsigelser på antallet af likes
```




    array([  76437.8151625 ,   93678.92809985,  101494.89929811,
           1623133.7120003 , 1583594.09299731,   83794.0233491 ,
            107241.9369439 ,   77357.34118582,   81954.97130245,
           1626352.05308194,   94138.69111151,   93449.04659402,
             93678.92809985,  104943.12188558,   96207.62466399,
             67012.67342341,   74828.64462168, 1629110.63115191,
           1582214.80396232,   75058.52612751,   78506.74871498,
            105173.00339141,   89541.06099488,   87702.00894823,
            101724.78080394,   92759.40207652,   94368.57261734,
            102644.30682727,   97357.03219315,   75058.52612751,
             95058.21713484,   81035.44527912,   90920.35002987,
             75978.05215084,   85173.31238409,   84713.54937243,
           1625202.64555278,   79426.27473831,   94598.45412317,
             90460.58701821, 1555778.43079172,   85403.19388992,
             99655.84725146,   88621.53497156,   82874.49732578,
           1611869.51821456,   88621.53497156,   95517.9801465 ,
             78506.74871498,   88851.41647739])




```python
#coefficienterne
print('Coefficienterne:', clf.coef_)
#gennemsnitlige kvadrerede forudsigelsesfejl også kendt som mean squared error
print('Den gennemsnitlige kvadrerede forudsigelsesfejl: %.2f'
      % mean_squared_error(test_y, y_pred))
# Forudsigelsesgraden: 1 er en perfect forudsigelse
print('Graden for præcis forudsigelse : %.2f'
      % r2_score(test_y, y_pred))
```

    Coefficienterne: [ 1.52807549e+06 -2.29881506e+02]
    Den gennemsnitlige kvadrerede forudsigelsesfejl: 80684597596.17
    Graden for præcis forudsigelse : 0.79


In statistics, the mean squared error (MSE) of an estimator (of a procedure for estimating an unobserved quantity) measures the average of the squares of the errors — that is, the average squared difference between the estimated values and what is estimated. MSE is a risk function, corresponding to the expected value of the squared error loss. The fact that MSE is almost always strictly positive (and not zero) is because of randomness or because the estimator does not account for information that could produce a more accurate estimate.


```python
#visualisering af de faktiske og forudsete værdier for antallet at likes
_, ax = plt.subplots()

ax.scatter(x = test_X['caption length'], y=test_y, c = 'blue', label = 'Faktiske', alpha = 0.3)
ax.scatter(x = test_X['caption length'], y=y_pred, c = 'red', label = 'Forudsete', alpha = 0.3)

plt.title('Faktiske vs forudsete værdier')
plt.xlabel('Caption length')
plt.ylabel('Likes')
plt.legend()
plt.show()
```


![png](output_90_0.png)


# Sentiment analysis


```python
#Opstiller en liste der indeholder sentimentets polaritet for hver caption 
polarity=[]
for i in df.caption:
    polarity.append(TextBlob(i).sentiment.polarity)
polarity[:10]
```




    [0.2375,
     0.0,
     -0.41666666666666663,
     0.0,
     0.0,
     0.0,
     0.0,
     0.2,
     0.2333333333333333,
     0.5]




```python
#opstiller en ny liste der fortolker graden af polaritet ud fra tidligere liste
polarity_lst=[]
for i in polarity:
    if i > 0.0: 
        polarity_lst.append('positive')
    elif i < 0.0: 
        polarity_lst.append('negative') 
    else: 
        polarity_lst.append('neutral')
polarity_lst[:10]
```




    ['positive',
     'neutral',
     'negative',
     'neutral',
     'neutral',
     'neutral',
     'neutral',
     'positive',
     'positive',
     'positive']




```python
#Opstiller en liste der indeholder sentimentets subjektivitet for hver caption 
subjectivity=[]
for i in df.caption:
    subjectivity.append(TextBlob(i).sentiment.subjectivity)
subjectivity[:10]
```




    [0.2895833333333333,
     0.0,
     0.6666666666666666,
     0.0,
     0.0,
     0.0,
     0.0,
     0.2625,
     0.35555555555555557,
     1.0]




```python
#opstiller en ny liste der fortolker graden af subjektivitet ud fra tidligere liste
subjectivity_lst=[]
for i in subjectivity:
    if i > 0: 
        subjectivity_lst.append('Subjektiv')
    else: 
        subjectivity_lst.append('Objektiv')
subjectivity_lst[:10]
```




    ['Subjektiv',
     'Objektiv',
     'Subjektiv',
     'Objektiv',
     'Objektiv',
     'Objektiv',
     'Objektiv',
     'Subjektiv',
     'Subjektiv',
     'Subjektiv']




```python
# Et samlet datasæt udgjort at de tidligere liste, der visuelt giver et overblik sentimentet for hver caption
df1 = pd.DataFrame(data={'Polarity':polarity, 'Result1':polarity_lst,'Subjectivity':subjectivity, 'Result2':subjectivity_lst, 'Caption':alle})
df1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Polarity</th>
      <th>Result1</th>
      <th>Subjectivity</th>
      <th>Result2</th>
      <th>Caption</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.237500</td>
      <td>positive</td>
      <td>0.289583</td>
      <td>Subjektiv</td>
      <td>This is the first step of MANY. KEEP THAT SAME...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.000000</td>
      <td>neutral</td>
      <td>0.000000</td>
      <td>Objektiv</td>
      <td>Wearing all Praying cause that's what all I be...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>-0.416667</td>
      <td>negative</td>
      <td>0.666667</td>
      <td>Subjektiv</td>
      <td>Fav distraction: Looking at apartments I can't...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.000000</td>
      <td>neutral</td>
      <td>0.000000</td>
      <td>Objektiv</td>
      <td>I know patience is a virtue, but DAMN!! Are we...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.000000</td>
      <td>neutral</td>
      <td>0.000000</td>
      <td>Objektiv</td>
      <td>Anxiety meter already broke 🤖 Recharging with ...</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>245</th>
      <td>0.000000</td>
      <td>neutral</td>
      <td>0.000000</td>
      <td>Objektiv</td>
      <td>Went through a breakup, wrote a song about it....</td>
    </tr>
    <tr>
      <th>246</th>
      <td>0.000000</td>
      <td>neutral</td>
      <td>0.000000</td>
      <td>Objektiv</td>
      <td>Y’all know how I am...I couldn’t help myself 🙃...</td>
    </tr>
    <tr>
      <th>247</th>
      <td>0.000000</td>
      <td>neutral</td>
      <td>0.100000</td>
      <td>Subjektiv</td>
      <td>Big things coming soon!</td>
    </tr>
    <tr>
      <th>248</th>
      <td>0.112121</td>
      <td>positive</td>
      <td>0.651515</td>
      <td>Subjektiv</td>
      <td>New tunes coming soon. Zoom in on my @samsungm...</td>
    </tr>
    <tr>
      <th>249</th>
      <td>0.225652</td>
      <td>positive</td>
      <td>0.534133</td>
      <td>Subjektiv</td>
      <td>⚠️ Long caption Alert ⚠️\nSo this is the inevi...</td>
    </tr>
  </tbody>
</table>
<p>250 rows × 5 columns</p>
</div>




```python
mean_pol=sum(polarity)/len(polarity) #Beregner gennemsnittet for polaritet
print('Gennemsnits polaritet:', mean_pol)
```

    Gennemsnits polaritet: 0.09579347057964786



```python
mean_sub=sum(subjectivity)/len(subjectivity) #Beregner gennemsnittet for subjektivitet
print('Gennemsnits subjektivtet:', mean_sub)
```

    Gennemsnits subjektivtet: 0.344851428753239



```python
df1['Result1'].value_counts().plot.bar(color=['pink', 'grey', 'lightblue'])
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7fd17c45f2d0>




![png](output_99_1.png)



```python
df1['Result2'].value_counts().plot.pie()
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7fd17c384e50>




![png](output_100_1.png)



```python
print('Procent for @lilmiquela subjektivtet:',df1['Result2'].str.count('Subjektiv').sum()/250*100, '%')
```

    Procent for @lilmiquela subjektivtet: 67.2 %



```python
print('Procent for @lilmiquela subjektivtet:',round(df1['Result1'].str.count('positive').sum()/250*100), '%')
```

    Procent for @lilmiquela subjektivtet: 46.0 %



```python

```
